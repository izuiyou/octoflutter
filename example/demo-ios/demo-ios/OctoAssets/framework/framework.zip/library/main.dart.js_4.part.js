self.$__dart_deferred_initializers__=self.$__dart_deferred_initializers__||Object.create(null)
$__dart_deferred_initializers__.current=function(a,b,c,$){var PART4={
Ioh(d){return new PART4.zoN(PART4_C.r9,null,null,null,d.CT("zoN<0>"))},
SbH:function SbH(d,e){this.a=d
this.b=e},
zoN:function zoN(d,e,f,g,h){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.$ti=h}},N,J,C,PART4_C
a.setFunctionNamesIfNecessary([PART4])
PART4=a.updateHolder(c[8],PART4)
window.PART4=PART4
N=c[0]
J=c[1]
C=c[2]
PART4_C=c[11]
window.PART4_C=PART4_C
PART4.SbH.prototype={
Z(d){return"ConnectionState."+this.b}}
PART4.zoN.prototype={
Z(d){var y=this
return"AsyncSnapshot("+y.a.Z(0)+", "+N.Ej(y.b)+", "+N.Ej(y.c)+", "+N.Ej(y.d)+")"},
DN(d,e){var y=this
if(e==null)return!1
if(y===e)return!0
return y.$ti.b(e)&&e.a===y.a&&J.RM(e.b,y.b)&&J.RM(e.c,y.c)&&e.d==y.d},
gE(d){return N.uW(this.a,this.b,this.c,C.nH,C.nH,C.nH,C.nH,C.nH,C.nH,C.nH,C.nH,C.nH,C.nH,C.nH,C.nH,C.nH,C.nH,C.nH,C.nH,C.nH)}}
var z=a.updateTypes([]);(function inheritance(){var y=a.inherit
y(PART4.SbH,N.cke)
y(PART4.zoN,N.Mh)})()
N.xbv(b.typeUniverse,JSON.parse('{"SbH":{"q8v":[]}}'));(function constants(){PART4_C.r9=new PART4.SbH(0,"none")
PART4_C.Ap=new PART4.SbH(1,"waiting")
PART4_C.e3=new PART4.SbH(3,"done")})()}
$__dart_deferred_initializers__["W6Fn3mACFPy2XORTXAU5cbgeDvY="] = $__dart_deferred_initializers__.current

window.init.initializeLoadedHunk("W6Fn3mACFPy2XORTXAU5cbgeDvY=");

