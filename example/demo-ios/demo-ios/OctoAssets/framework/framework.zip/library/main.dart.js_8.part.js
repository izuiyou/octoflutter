self.$__dart_deferred_initializers__=self.$__dart_deferred_initializers__||Object.create(null)
$__dart_deferred_initializers__.current=function(a,b,c,$){var PART8={VuK:function VuK(d,e,f){this.a=d
this.b=e
this.$ti=f},qwE:function qwE(d,e,f){this.a=d
this.b=e
this.$ti=f},mV4:function mV4(d,e){this.a=d
this.b=e},lmJ:function lmJ(d,e,f,g,h,i,j,k,l,m,n,o){var _=this
_.cx=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i
_.r=j
_.x=k
_.y=l
_.z=m
_.Q=n
_.a=o},wIn:function wIn(d,e,f,g,h,i,j,k){var _=this
_.Q=d
_.c=e
_.d=f
_.e=g
_.f=h
_.r=i
_.x=j
_.a=k},xvE:function xvE(d,e,f){var _=this
_.Q=_.z=$
_.ch=null
_.d=$
_.qQ$=d
_.Qc$=e
_.a=null
_.b=f
_.c=null},NKO:function NKO(d){this.a=d},ywS:function ywS(d,e,f,g){var _=this
_.LD=d
_.My=null
_.RZ=e
_.Ik$=f
_.r1=_.k4=null
_.r2=!1
_.ry=_.rx=null
_.x1=0
_.d=!1
_.f=_.e=null
_.x=_.r=!1
_.y=null
_.z=!1
_.Q=!0
_.ch=null
_.cx=!1
_.cy=null
_.db=!1
_.dx=g
_.dy=!1
_.fr=$
_.fx=!0
_.fy=null
_.go=!0
_.id=null
_.a=0
_.c=_.b=null},kMJ:function kMJ(d){this.a=d},ykS:function ykS(){},rwN:function rwN(d,e,f){this.e=d
this.c=e
this.a=f},
BEC(d){var x=J.U6(d),w=x.q(d,""),v=x.q(d,""),u=x.q(d,""),t=x.q(d,""),s=x.q(d,""),r=x.q(d,""),q=x.q(d,""),p=x.q(d,""),o=x.q(d,""),n=x.q(d,""),m=x.q(d,""),l=x.q(d,""),k=x.q(d,""),j=x.q(d,""),i=x.q(d,""),h=x.q(d,""),g=x.q(d,"")
return new PART8.SmartRefresher(u,t,s,q,p,r,o,n,m,v,x.q(d,""),h,x.q(d,""),k,g,j,i,l,w)},
MpY(d){return PART8_C.ZT},
TWS(d){return PART8_C.tV},
VoD(d){return PART8_C.Ol},
Gip(d){return PART8_C.D2},
refreshControllerInstance(d,e,f){var x=d===!0,w=e==null?PART8_C.RefreshStatus_0:e,v=f==null?PART8_C.LoadStatus_0:f,u=new PART8.b3(x)
u.p(v,x,w)
return u},
rHt(d){var x=J.x9(d,""),w=new PART8.OctoRefreshController(x,!1)
w.p(null,!1,null)
return[w,x.gh1(),x.giH(),x.gbM(x),x.gVt(),x.ghK(),x.gHI(),x.gV0(),x.gqq(),x.gQr(),w.gva(),w.gUC(),w.gvr(),w.gVx(),w.gGE(),w.gCw(),w.gTz(),w.gD6(),w.gZV(),w.gXE(),w.gyB(),w.gUj(),w.gm8(w),w.gvX(),w.gtc(),w.gvZ(),w.gS2(),w.gN9(),w.gUu(),w.gGz(),w.guk(),w.gmn(),w.gbk(),w.gOd(),w.gCR(w)]},
NPh(d){var x=J.U6(d),w=x.q(d,""),v=x.q(d,""),u=x.q(d,""),t=x.q(d,""),s=x.q(d,""),r=x.q(d,""),q=x.q(d,""),p=x.q(d,""),o=x.q(d,""),n=x.q(d,""),m=x.q(d,""),l=x.q(d,""),k=x.q(d,""),j=x.q(d,""),i=x.q(d,""),h=x.q(d,""),g=x.q(d,""),f=x.q(d,"")
return PART8.X4(o,m,t,x.q(d,""),l,f,k,u,i,x.q(d,""),j,w,s,v,g,p,x.q(d,""),q,h,r,n)},
tBY(d){var x=J.U6(d),w=x.q(d,""),v=x.q(d,""),u=x.q(d,""),t=x.q(d,""),s=x.q(d,""),r=x.q(d,""),q=x.q(d,""),p=x.q(d,""),o=x.q(d,""),n=x.q(d,""),m=x.q(d,""),l=x.q(d,""),k=x.q(d,""),j=x.q(d,""),i=x.q(d,""),h=x.q(d,""),g=x.q(d,"")
return PART8.PQ(x.q(d,""),l,h,k,m,t,j,x.q(d,""),n,w,u,g,q,p,o,v,s,i,r)},
pqG(d){return PART8_C.cu},
bzM(d){var x,w,v=J.U6(d),u=v.q(d,""),t=v.q(d,""),s=v.q(d,""),r=v.q(d,""),q=v.q(d,""),p=v.q(d,"")
v.q(d,"")
x=v.q(d,"")
w=v.q(d,"")
return new PART8.CustomHeader(t,s,r,q,p,v.q(d,""),x,0,w,u)},
Usd(d){var x=J.U6(d),w=x.q(d,""),v=x.q(d,""),u=x.q(d,""),t=x.q(d,""),s=x.q(d,""),r=x.q(d,""),q=x.q(d,"")
return new PART8.CustomFooter(x.q(d,""),t,u,s,r,q,v,y.Z.a(x.q(d,"")),w)},
p7(d){var x=d.a
x.t(0,"SmartRefresher",PART8.kw())
d.M9("RefreshStatus",9,PART8.nR())
d.M9("LoadStatus",5,PART8.U0())
d.M9("RefreshStyle",4,PART8.Su())
d.M9("LoadStyle",3,PART8.N0())
d.d.t(0,"refreshControllerInstance",PART8.G7())
x.t(0,"OctoRefreshController",PART8.w5())
x.t(0,"ClassicHeader",PART8.WP())
x.t(0,"ClassicFooter",PART8.VO())
d.M9("IconPosition",4,PART8.YV())
x.t(0,"CustomHeader",PART8.aT())
x.t(0,"CustomFooter",PART8.Pw())},
OctoRefreshController:function OctoRefreshController(d,e){var _=this
_.f=d
_.d=_.c=_.b=_.a=null
_.e=e},
cl:function cl(d){this.a=d},
Fl:function Fl(d){this.a=d},
Hq:function Hq(d){this.a=d},
KE:function KE(d){this.a=d},
Wq:function Wq(d){this.a=d},
Ml:function Ml(d){this.a=d},
X4(d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x){return new PART8.ClassicHeader(p,u,n,s,h,j,e,t,m,r,g,i,d,x,v,l,w,q,k,0,f,o)},
PQ(d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v){return new PART8.ClassicFooter(l,p,q,h,e,t,k,o,r,g,d,u,j,v,f,n,i,s,m)},
Ela:function Ela(d,e){this.a=d
this.b=e},
ClassicHeader:function ClassicHeader(d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,a0){var _=this
_.x=d
_.y=e
_.z=f
_.Q=g
_.ch=h
_.cx=i
_.cy=j
_.db=k
_.dx=l
_.dy=m
_.fr=n
_.fx=o
_.fy=p
_.go=q
_.id=r
_.k1=s
_.k2=t
_.c=u
_.d=v
_.e=w
_.f=x
_.a=a0},
Hyq:function Hyq(d,e,f,g,h,i){var _=this
_.lG$=d
_.C7$=e
_.Va$=f
_.CD$=g
_.j3$=h
_.a=null
_.b=i
_.c=null},
ClassicFooter:function ClassicFooter(d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v){var _=this
_.r=d
_.x=e
_.y=f
_.z=g
_.Q=h
_.ch=i
_.cx=j
_.cy=k
_.db=l
_.dx=m
_.dy=n
_.fr=o
_.fx=p
_.fy=q
_.go=r
_.c=s
_.d=t
_.e=u
_.a=v},
WYN:function WYN(d,e,f,g,h,i,j){var _=this
_.e=_.d=!1
_.f=d
_.lG$=e
_.C7$=f
_.Va$=g
_.CD$=h
_.j3$=i
_.a=null
_.b=j
_.c=null},
CustomHeader:function CustomHeader(d,e,f,g,h,i,j,k,l,m){var _=this
_.x=d
_.y=e
_.z=f
_.Q=g
_.ch=h
_.c=i
_.d=j
_.e=k
_.f=l
_.a=m},
DyT:function DyT(d,e,f,g,h,i){var _=this
_.lG$=d
_.C7$=e
_.Va$=f
_.CD$=g
_.j3$=h
_.a=null
_.b=i
_.c=null},
CustomFooter:function CustomFooter(d,e,f,g,h,i,j,k,l){var _=this
_.r=d
_.x=e
_.y=f
_.z=g
_.Q=h
_.c=i
_.d=j
_.e=k
_.a=l},
TpB:function TpB(d,e,f,g,h,i,j){var _=this
_.e=_.d=!1
_.f=d
_.lG$=e
_.C7$=f
_.Va$=g
_.CD$=h
_.j3$=i
_.a=null
_.b=j
_.c=null},
ACY:function ACY(d,e,f,g,h){var _=this
_.c=d
_.d=e
_.e=f
_.f=g
_.a=h},
nJ4:function nJ4(d,e,f,g,h,i,j,k){var _=this
_.cy=_.cx=_.ch=null
_.dy=_.dx=_.db=$
_.ub$=d
_.WX$=e
_.lG$=f
_.C7$=g
_.Va$=h
_.CD$=i
_.j3$=j
_.a=null
_.b=k
_.c=null},
jrg:function jrg(d){this.a=d},
Var:function Var(){},
f39:function f39(){},
Rr:function Rr(){},
Ds:function Ds(){},
I6H:function I6H(){},
Jgn:function Jgn(d){this.a=d},
FVg:function FVg(d){this.a=d},
GU3:function GU3(d){this.a=d},
AyK:function AyK(d){this.a=d},
wqs:function wqs(d){this.a=d},
Tf9:function Tf9(){},
xiU:function xiU(d){this.a=d},
HKg:function HKg(d){this.a=d},
NkG:function NkG(d){this.a=d},
ApV:function ApV(d){this.a=d},
WtH:function WtH(d){this.a=d},
TCS:function TCS(d){this.a=d},
igW:function igW(d){this.a=d},
RC6:function RC6(){},
K6U:function K6U(){},
mlR:function mlR(){},
u3w:function u3w(){},
ol0:function ol0(){},
y2N:function y2N(){},
xvw:function xvw(){},
wbs:function wbs(){},
kBB(d,e,f){var x,w
if(d>0){x=d/f
if(e<x)return e*f
w=0+d
e-=x}else w=0
return w+e},
Zs6:function Zs6(d,e,f,g,h,i,j,k,l,m,n){var _=this
_.b=d
_.c=e
_.d=f
_.e=g
_.f=h
_.r=i
_.x=j
_.y=k
_.z=l
_.Q=m
_.ch=null
_.a=n},
bPC:function bPC(d,e){this.a=d
this.b=e},
QVC:function QVC(d,e,f,g,h,i){var _=this
_.e=d
_.f=e
_.r=f
_.x=g
_.c=h
_.a=i},
Xo8:function Xo8(d,e,f,g,h,i){var _=this
_.eD=d
_.jq=$
_.vk=e
_.ol=f
_.Ht=!1
_.HV=g
_.cf=0
_.Ik$=h
_.k4=null
_.d=!1
_.f=_.e=null
_.x=_.r=!1
_.y=null
_.z=!1
_.Q=!0
_.ch=null
_.cx=!1
_.cy=null
_.db=!1
_.dx=i
_.dy=!1
_.fr=$
_.fx=!0
_.fy=null
_.go=!0
_.id=null
_.a=0
_.c=_.b=null},
Rs4:function Rs4(d,e,f,g,h,i,j){var _=this
_.e=d
_.f=e
_.r=f
_.x=g
_.y=h
_.c=i
_.a=j},
f5Y:function f5Y(d,e,f,g,h){var _=this
_.eD=d
_.jq=e
_.vk=f
_.Ht=_.ol=null
_.Ik$=g
_.k4=null
_.d=!1
_.f=_.e=null
_.x=_.r=!1
_.y=null
_.z=!1
_.Q=!0
_.ch=null
_.cx=!1
_.cy=null
_.db=!1
_.dx=h
_.dy=!1
_.fr=$
_.fx=!0
_.fy=null
_.go=!0
_.id=null
_.a=0
_.c=_.b=null},
O06:function O06(d,e){this.c=d
this.a=e},
KeT:function KeT(d,e){var _=this
_.Ik$=d
_.k4=null
_.d=!1
_.f=_.e=null
_.x=_.r=!1
_.y=null
_.z=!1
_.Q=!0
_.ch=null
_.cx=!1
_.cy=null
_.db=!1
_.dx=e
_.dy=!1
_.fr=$
_.fx=!0
_.fy=null
_.go=!0
_.id=null
_.a=0
_.c=_.b=null},
KrM:function KrM(d,e){this.a=d
this.b=e},
kj0:function kj0(d,e){this.a=d
this.b=e},
ADR:function ADR(d,e){this.a=d
this.b=e},
GzT:function GzT(d,e){this.a=d
this.b=e},
SmartRefresher:function SmartRefresher(d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v){var _=this
_.c=d
_.d=e
_.e=f
_.f=g
_.r=h
_.x=i
_.y=j
_.z=k
_.Q=l
_.ch=m
_.cy=n
_.db=o
_.dx=p
_.dy=q
_.fr=r
_.fx=s
_.fy=t
_.go=u
_.a=v},
eDm:function eDm(d,e,f){var _=this
_.d=null
_.e=!1
_.f=0
_.r=!0
_.x=d
_.y=e
_.a=null
_.b=f
_.c=null},
Mms:function Mms(d,e,f){this.a=d
this.b=e
this.c=f},
U2:function U2(d,e){this.a=d
this.b=e},
vrX:function vrX(d){this.a=d},
kQQ:function kQQ(d,e){this.a=d
this.b=e},
b3:function b3(d){var _=this
_.d=_.c=_.b=_.a=null
_.e=d},
kD:function kD(d,e,f){this.a=d
this.b=e
this.c=f},
wV:function wV(d,e,f,g,h){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h},
W6:function W6(d,e,f){this.a=d
this.b=e
this.c=f},
Gp:function Gp(){},
pX:function pX(d){this.a=d},
DY:function DY(d,e,f){this.a=d
this.b=e
this.c=f},
Af:function Af(d,e,f,g,h){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h},
NO:function NO(d,e,f){this.a=d
this.b=e
this.c=f},
oS:function oS(){},
S5:function S5(d){this.a=d},
on:function on(d,e,f){this.a=d
this.b=e
this.c=f},
qb:function qb(d){this.a=d},
ht:function ht(d){this.a=d},
eq:function eq(d){this.a=d},
x4:function x4(d){this.a=d},
vYQ:function vYQ(d,e,f){this.f=d
this.b=e
this.a=f},
ov:function ov(d,e,f){var _=this
_.a=d
_.k3$=0
_.k4$=e
_.r2$=_.r1$=0
_.rx$=!1
_.$ti=f},
fR6:function fR6(d){this.a=d}},C,N,PART8_C,J
a.setFunctionNamesIfNecessary([PART8])
PART8=a.updateHolder(c[7],PART8)
window.PART8=PART8
C=c[2]
N=c[0]
PART8_C=c[14]
window.PART8_C=PART8_C
J=c[1]
PART8.VuK.prototype={
pU(d,e){var x,w,v,u,t,s,r,q=this.a
C.Nm.FV(q,d)
for(x=q.length,w=0,v=0;v<x;++v)w+=q[v].b
for(x=this.b,u=0,t=0;s=q.length,t<s;++t,u=r){r=t===s-1?1:u+q[t].b/w
x.push(new PART8.mV4(u,r))}},
iSk(d,e){var x=this.a[e],w=this.b[e],v=w.a
return x.a.At(0,(d-v)/(w.b-v))},
At(d,e){var x,w,v,u,t,s,r=this
if(e===1)return r.iSk(e,r.a.length-1)
for(x=r.a,w=x.length,v=r.b,u=0;u<w;++u){t=v[u]
s=t.a
if(e>=s&&e<t.b)return x[u].a.At(0,(e-s)/(t.b-s))}throw N.c(N.PV("TweenSequence.evaluate() could not find an interval for "+N.Ej(e)))},
Z(d){return"TweenSequence("+this.a.length+" items)"}}
PART8.qwE.prototype={}
PART8.mV4.prototype={
Z(d){return"<"+N.Ej(this.a)+", "+N.Ej(this.b)+">"}}
PART8.lmJ.prototype={
It(d,e){var x,w,v,u,t,s,r,q,p,o,n,m=this
m.tZS(d,e)
x=m.cx
if(x>0){w=m.z+m.Q
v=Math.cos(w)
u=Math.sin(w)
t=e.a/2
s=m.y
r=s*2*x
q=t-r
p=t+r
o=N.Fs()
o.bJ(0,t+v*q,t+u*q)
o.Fp(0,t+v*p,t+u*p)
o.Fp(0,t+v*t+-u*s*2*x,t+u*t+v*s*2*x)
o.xO(0)
n=N.VQ()
n.sih(0,m.c)
n.sD8(s)
n.sq5(0,C.PaintingStyle_0)
d.bB(0,o,n)}}}
PART8.wIn.prototype={
gVp(d){return N.CircularProgressIndicator.prototype.gVp.call(this,this)},
wga(){return new PART8.xvE(null,null,C.ed)}}
PART8.xvE.prototype={
wgb(d,e){var x,w,v=this,u=v.a.c
if(u!=null){v.ch=u
x=N.mk(v.d,"_controller")
w=v.z
if(w===$){N.CL(w,"_convertTween")
w=v.z=new N.A0(PART8_C.tB)}x.snw(0,w.At(0,u)*0.000225022502250225)}return v.i4()},
i4(){return N.f0(N.mk(this.d,"_controller"),new PART8.NKO(this),null)},
TF(d,e,f,g,h){var x,w,v,u,t,s,r,q,p,o=this,n=null,m=o.a.c,l=m==null,k=l?0:PART8_C.tB.At(0,m)
if(l&&o.ch==null)x=0
else{w=o.Q
if(w===$){v=y.Y
u=y.V
t=y.T
u=N.J([new PART8.qwE(new N.bL(-0.1,-0.2,v),0.33,u),new PART8.qwE(new N.bL(-0.2,1.35,v),0.6699999999999999,u)],t)
s=new PART8.VuK(N.J([],t),N.J([],y.O),y.U)
s.pU(u,y._)
N.CL(o.Q,"_additionalRotationTween")
o.Q=s
w=s}if(l){l=o.ch
l.toString}else l=m
x=3.141592653589793*w.At(0,l)}r=o.a.er(d)
l=r.gnw(r)
r=N.yK(255,r.gnw(r)>>>16&255,r.gnw(r)>>>8&255,r.gnw(r)&255)
v=o.a
v=v.gVp(v)
q=v==null?N.aan(d).e:v
if(q==null)q=N.lB(d).fx
v=o.a
u=v.Q
t=f*3/2*3.141592653589793
p=Math.max(e*3/2*3.141592653589793-t,0.001)
return v.DuC(N.jQB(n,N.OU(C.FG,!0,n,new N.Padding(C.j9,new N.Opacity((l>>>24&255)/255,!1,N.iJ(C.wn,x,N.OV(n,n,!1,n,new PART8.lmJ(k,n,r,n,e,f,g,h,u,-1.5707963267948966+t+h*3.141592653589793*2+g*0.5*3.141592653589793,p,n),C.wl,!1),n),n),n),C.Clip_0,q,2,n,n,n,n,C.XL),C.Clip_0,n,n,n,n,41,n,C.a1,n,n,n,41),d)}}
PART8.ywS.prototype={
sCt4(d){if(this.LD===d)return
this.LD=d
this.Ae()},
n4G(d){var x=this.Ik$
if(x==null)return 0
return(this.LD&1)===1?x.J8g(C.Lq,d,x.gL3E()):x.J8g(C.or,d,x.gTsy())},
Emj(d){var x=this.Ik$
if(x==null)return 0
return(this.LD&1)===1?x.J8g(C.pD,d,x.gBhg()):x.J8g(C.q7,d,x.gc9D())},
MZD(d){var x=this.Ik$
if(x==null)return 0
return(this.LD&1)===1?x.J8g(C.or,d,x.gTsy()):x.J8g(C.Lq,d,x.gL3E())},
Gse(d){var x=this.Ik$
if(x==null)return 0
return(this.LD&1)===1?x.J8g(C.q7,d,x.gc9D()):x.J8g(C.pD,d,x.gBhg())},
WYH(d){var x,w=this.Ik$
if(w==null)return new N.Size(C.jn.IV(0,d.a,d.b),C.jn.IV(0,d.c,d.d))
x=w.UjZ((this.LD&1)===1?d.gL9i():d)
return(this.LD&1)===1?new N.Size(x.b,x.a):x},
K1t(){var x,w,v=this
v.My=null
x=v.Ik$
if(x!=null){w=y.k
x.yEC(0,(v.LD&1)===1?w.a(N.jU.prototype.gHv.call(v)).gL9i():w.a(N.jU.prototype.gHv.call(v)),!0)
x=v.LD
w=v.Ik$
if((x&1)===1){x=w.rx
x=new N.Size(x.b,x.a)}else{x=w.rx
x.toString}v.rx=x
x=new N.Matrix4(new Float64Array(16))
x.xI()
w=v.rx
x.QI(0,w.a/2,w.b/2)
x.cB(1.5707963267948966*C.jn.zY(v.LD,4))
w=v.Ik$.rx
x.QI(0,-w.a/2,-w.b/2)
v.My=x}else{x=y.k.a(N.jU.prototype.gHv.call(v))
v.rx=new N.Size(C.jn.IV(0,x.a,x.b),C.jn.IV(0,x.c,x.d))}},
vT(d,e){var x=this
if(x.Ik$==null||x.My==null)return!1
return d.zKd(new PART8.kMJ(x),e,x.My)},
oJj(d,e){var x=this.Ik$
x.toString
d.u3i(x,e)},
It(d,e){var x,w,v=this,u=v.RZ
if(v.Ik$!=null){x=N.mk(v.fr,"_needsCompositing")
w=v.My
w.toString
u.sPX(0,d.G8w(x,e,w,v.gDRK(),u.a))}else u.sPX(0,null)},
dispose(d){this.RZ.sPX(0,null)
this.p5T(0)},
kl(d,e){var x=this.My
if(x!=null)e.tv(0,x)
this.OGR(d,e)}}
PART8.ykS.prototype={
UE(d){var x
this.Zb(d)
x=this.Ik$
if(x!=null)x.UE(d)},
Ie(d){var x
this.M1(0)
x=this.Ik$
if(x!=null)x.Ie(0)}}
PART8.rwN.prototype={
Xb(d){var x=new PART8.ywS(this.e,N.amA(),null,N.amA())
x.gup()
x.gLX()
x.fr=!1
x.swz(null)
return x},
ls(d,e){e.sCt4(this.e)}}
PART8.OctoRefreshController.prototype={
gh1(){return this.f.gh1()},
sh1(d){this.f.sh1(d)},
giH(){return this.f.giH()},
siH(d){this.f.siH(d)},
sbM(d,e){this.f.sbM(0,e)},
gbM(d){var x=this.f
return x.gbM(x)},
gVt(){return this.f.gVt()},
ghK(){return this.f.ghK()},
gHI(){return this.f.gHI()},
gV0(){return this.f.gV0()},
gqq(){return this.f.gqq()},
gQr(){return this.f.gQr()},
HP(d){this.f.HP(d)},
eU(d,e,f,g){return this.f.eU(d,e,f,g)},
hyZ(){return this.eU(C.t0,C.Ng,!0,!0)},
jQp(d,e){return this.eU(d,e,!0,!0)},
Ep(d,e,f,g){return this.f.Ep(d,e,f,g)},
RqZ(){return this.Ep(C.t0,C.TJ,!0,!0)},
n83(d,e){return this.Ep(d,e,!0,!0)},
Sf(d,e){return this.f.Sf(d,e)},
Iu4(){return this.Sf(C.t0,C.TJ)},
mN(d){this.f.mN(d)},
bfK(){return this.mN(!1)},
vY(d,e){return this.f.vY(d,e)},
L92(){return this.vY(C.t0,C.Ng)},
O2(){this.f.O2()},
u2(){this.f.u2()},
dG(){this.f.dG()},
Fv(){this.f.Fv()},
AX(){this.f.AX()},
CO(){this.f.CO()},
dispose(d){this.f.dispose(0)
this.LY(0)},
rha(d,e,f,g,h,i){var x=this.f.eU(g,f,e,d)
if(x!=null)x.W7(0,new PART8.cl(h),y.P).OA(new PART8.Fl(i))
else i.$1("request null")},
rhb(d,e,f,g){this.f.Sf(e,d).W7(0,new PART8.Hq(f),y.P).OA(new PART8.KE(g))},
rhc(d,e,f,g,h,i){var x=this.f.Ep(g,f,e,d)
if(x!=null)x.W7(0,new PART8.Wq(h),y.P).OA(new PART8.Ml(i))
else i.$1("request null")},
rhd(d){this.f.mN(d)},
rhe(d,e,f,g){this.f.vY(e,d)
g.$1("two level null")},
rhf(){this.f.O2()},
rhg(){this.f.u2()},
rhi(){this.f.dG()},
rhj(){this.f.Fv()},
rhk(){this.f.AX()},
rhl(){this.f.CO()},
Z(d){var x=this.f
return x.Z(0)+(" hashCode:"+N.eQ(x))}}
PART8.Ela.prototype={
Z(d){return"IconPosition."+this.b}}
PART8.ClassicHeader.prototype={
wga(){var x=null
return new PART8.Hyq(x,x,!1,x,x,C.ed)}}
PART8.Hyq.prototype={
rCu(){return!1},
JTf(d,e){var x,w,v,u,t,s,r,q,p=this,o=null,n=p.c
n.toString
N.qv(n,PART8_C.il,y.D)
n=e===PART8_C.RefreshStatus_1
if(n){x=p.a.y
if(x==null)x="Release to refresh"}else if(e===PART8_C.RefreshStatus_3){x=p.a.ch
if(x==null)x="Refresh completed"}else if(e===PART8_C.RefreshStatus_4){x=p.a.cx
if(x==null)x="Refresh failed"}else if(e===PART8_C.RefreshStatus_2){x=p.a.Q
if(x==null)x="Refreshing\u2026"}else if(e===PART8_C.RefreshStatus_0){x=p.a.z
if(x==null)x="Pull down Refresh"}else if(e===PART8_C.RefreshStatus_5){x=p.a.cy
if(x==null)x="Release to enter secondfloor"}else x=""
w=p.a
v=N.Ii(x,o,o,o,o,o,o,o,w.k2,o,o,o,o,o)
if(n)u=w.db
else if(e===PART8_C.RefreshStatus_0){n=w.dx
u=n}else{if(e===PART8_C.RefreshStatus_3)n=w.fr
else if(e===PART8_C.RefreshStatus_4)n=w.fx
else if(e===PART8_C.RefreshStatus_5)n=w.fy
else if(e===PART8_C.RefreshStatus_2){n=w.dy
if(n==null)n=new N.SizedBox(25,25,N.HA()===C.TargetPlatform_2?PART8_C.zi:PART8_C.R5,o)}else n=w.go
u=n}t=N.J([u==null?N.jQB(o,o,C.Clip_0,o,o,o,o,o,o,o,o,o,o,o):u,v],y.p)
n=p.a
x=n.id
w=n.k1
s=w===PART8_C.IconPosition_0?C.TextDirection_1:C.TextDirection_0
r=w===PART8_C.IconPosition_3
w=r||w===PART8_C.IconPosition_2?C.Axis_1:C.Axis_0
q=N.x5(C.WrapAlignment_2,t,C.Clip_0,C.WrapCrossAlignment_2,w,o,C.WrapAlignment_0,0,x,s,r?C.VerticalDirection_0:C.VerticalDirection_1)
x=n.x
return x!=null?x.$1(q):N.jQB(o,N.Pv(q,o,o,o),C.Clip_0,o,o,o,o,n.d,o,o,o,o,o,o)}}
PART8.ClassicFooter.prototype={
wga(){var x=null
return new PART8.WYN(PART8_C.LoadStatus_0,x,x,!1,x,x,C.ed)}}
PART8.WYN.prototype={
RP(){return N.dT(this.a.go,null,y.z)},
JTf(d,e){var x,w,v,u,t,s,r,q,p,o=this,n=null,m=o.c
m.toString
N.qv(m,PART8_C.il,y.D)
m=e===PART8_C.LoadStatus_2
if(m){x=o.a
w=x.x
if(w==null)w="Loading\u2026"
v=w
w=x
x=v}else if(PART8_C.LoadStatus_3===e){x=o.a
w=x.y
if(w==null)w="No more data"
v=w
w=x
x=v}else if(PART8_C.LoadStatus_4===e){x=o.a
w=x.z
if(w==null)w="Load Failed"
v=w
w=x
x=v}else{x=o.a
if(PART8_C.LoadStatus_1===e){w=x.Q
if(w==null)w="Release to load more"}else{w=x.r
if(w==null)w="Pull up Load more"}v=w
w=x
x=v}u=N.Ii(x,n,n,n,n,n,n,n,w.fy,n,n,n,n,n)
if(m){m=w.cy
if(m==null){m=new N.SizedBox(25,25,N.HA()===C.TargetPlatform_2?PART8_C.zi:PART8_C.R5,n)
t=m}else t=m}else if(e===PART8_C.LoadStatus_3){m=w.db
t=m}else{if(e===PART8_C.LoadStatus_4)m=w.dx
else m=e===PART8_C.LoadStatus_1?w.dy:w.cx
t=m}s=N.J([t==null?N.jQB(n,n,C.Clip_0,n,n,n,n,n,n,n,n,n,n,n):t,u],y.p)
m=o.a
x=m.fr
w=m.fx
r=w===PART8_C.IconPosition_0?C.TextDirection_1:C.TextDirection_0
q=w===PART8_C.IconPosition_3
w=q||w===PART8_C.IconPosition_2?C.Axis_1:C.Axis_0
p=N.x5(C.WrapAlignment_2,s,C.Clip_0,C.WrapCrossAlignment_2,w,n,C.WrapAlignment_0,0,x,r,q?C.VerticalDirection_0:C.VerticalDirection_1)
x=m.ch
if(x!=null)m=x.$1(p)
else{m=m.d
m=N.jQB(n,N.Pv(p,n,n,n),C.Clip_0,n,n,n,n,m,n,n,n,n,n,n)}return m}}
PART8.CustomHeader.prototype={
wga(){var x=null
return new PART8.DyT(x,x,!1,x,x,C.ed)},
Cl(d,e){return this.x.$2(d,e)}}
PART8.DyT.prototype={
kIP(d){var x=this.a.Q
if(x!=null)x.$1(d)
this.rSh(d)},
eLk(d){var x=this.a.ch
if(x!=null)x.$1(d)
this.ofn(d)},
fzC(){var x=this.a.y
if(x!=null)return x.$0()
return this.crj()},
H1t(){var x=this.a.z
if(x!=null)return x.$0()
return this.H3i()},
JTf(d,e){return this.a.Cl(d,e)}}
PART8.CustomFooter.prototype={
wga(){var x=null
return new PART8.TpB(PART8_C.LoadStatus_0,x,x,!1,x,x,C.ed)},
Cl(d,e){return this.r.$2(d,e)}}
PART8.TpB.prototype={
kIP(d){var x=this.a.x
if(x!=null)x.$1(d)
this.Bpd(d)},
eLk(d){var x=this.a.y
if(x!=null)x.$1(d)
this.axr(d)},
L10(){var x=this.a.z
if(x!=null)return x.$0()
return this.C5()},
RP(){var x=this.a.Q
if(x!=null)return x.$0()
return this.xef()},
JTf(d,e){return this.a.Cl(d,e)}}
PART8.ACY.prototype={
wga(){var x=null
return new PART8.nJ4(x,x,x,x,!1,x,x,C.ed)}}
PART8.nJ4.prototype={
initState(){var x,w,v=this,u=null,t=N.WjG(C.AnimationBehavior_0,u,N.xC(0,0,0,500,0,0),0,u,1,0,v)
v.dy=t
t=N.mk(t,"_valueAni")
t.St()
t=t.lq$
t.b=!0
t.a.push(new PART8.jrg(v))
v.dx=N.WjG(C.AnimationBehavior_0,u,N.xC(0,0,0,300,0,0),0,u,1,u,v)
v.db=N.WjG(C.AnimationBehavior_0,u,N.xC(0,0,0,300,0,0),0,u,1,1,v)
t=N.mk(v.dx,"_positionController")
x=v.a.d
w=y.L
v.cx=new N.pML(y.m.a(t),new N.bL(new N.Offset(0,-1),new N.Offset(0,x/44),w),w.CT("pML<Animatable.T>"))
v.eXk()},
didUpdateWidget(d){var x=this.c
x.toString
x=N.G0I(x).d
x.toString
this.ch=x
this.h0O(d)},
JTf(d,e){var x,w,v=this,u=null
v.a.toString
x=N.mk(v.db,"_scaleFactor")
v.a.toString
w=v.c
w.toString
N.qv(w,C.Ld,y.y).toString
v.a.toString
w=v.Va$?u:N.mk(N.mk(v.dy,"_valueAni").y,"_value")
x=N.LS(C.wn,new N.Align(C.Ur,u,u,new PART8.wIn(2.5,w,C.nY,u,v.cy,"Refresh",u,u),u),u,x)
w=v.cx
w.toString
return new N.SlideTransition(u,!0,x,w,u)},
kIP(d){var x,w,v=this
if(!v.Va$){x=N.mk(v.dy,"_valueAni")
v.lG$.toString
w=d/80
x.snw(0,w)
x=N.mk(v.dx,"_positionController")
v.lG$.toString
x.snw(0,w)}},
eLk(d){var x=this
if(d===PART8_C.RefreshStatus_2){N.mk(x.dx,"_positionController").snw(0,50/x.a.d)
N.mk(x.db,"_scaleFactor").snw(0,1)}x.ofn(d)},
C4m(){var x=this
N.mk(x.db,"_scaleFactor").snw(0,1)
N.mk(x.dx,"_positionController").snw(0,0)
N.mk(x.dy,"_valueAni").snw(0,0)
x.qxH()},
didChangeDependencies(){var x,w,v,u,t=this,s=t.c
s.toString
x=N.lB(s)
s=t.c
s.toString
s=N.G0I(s).d
s.toString
t.ch=s
s=N.mk(t.dx,"_positionController")
t.a.toString
w=x.cx
v=N.yK(0,w.gnw(w)>>>16&255,w.gnw(w)>>>8&255,w.gnw(w)&255)
t.a.toString
w=N.yK(255,w.gnw(w)>>>16&255,w.gnw(w)>>>8&255,w.gnw(w)&255)
u=y.h.CT("aP<Animatable.T>")
t.cy=new N.pML(y.m.a(s),new N.aP(new N.A0(PART8_C.fU),new N.hA(v,w),u),u.CT("pML<Animatable.T>"))
t.Lvi()},
fzC(){var x=N.mk(this.dx,"_positionController"),w=this.a.d
x.Q=C.MP
return x.LP(50/w,C.t0,null)},
H1t(){var x=N.mk(this.db,"_scaleFactor")
x.Q=C.MP
return x.LP(0,C.t0,null)},
dispose(d){var x=this
N.mk(x.dy,"_valueAni").dispose(0)
N.mk(x.db,"_scaleFactor").dispose(0)
N.mk(x.dx,"_positionController").dispose(0)
x.CDa(0)},
$iDGe:1}
PART8.f39.prototype={
f6(){this.Nza()
this.ef()
this.iw()},
dispose(d){var x=this,w=x.WX$
if(w!=null)w.Au(0,x.gOB())
x.WX$=null
x.hNl(0)}}
PART8.Rr.prototype={}
PART8.Ds.prototype={}
PART8.I6H.prototype={
EX(){var x,w,v=this
if(v.Va$)x=v.gFWV(v)===PART8_C.RefreshStatus_7||v.gFWV(v)===PART8_C.RefreshStatus_6||v.gFWV(v)===PART8_C.RefreshStatus_8?v.C7$.f:v.a.d
else x=0
w=v.j3$
if(w==null)w=null
else{w=w.cx
w.toString}return x-N.jf(w)},
BIm(){this.AxG()
this.kIP(this.EX())},
zaP(d){var x,w,v,u=this
if(u.gFWV(u)===PART8_C.RefreshStatus_7){x=u.j3$
w=x.cx
w.toString
u.lG$.toString
if(w>80&&x.k1 instanceof N.ei){u.C7$.a.ch.L92()
return}}if(PART8_C.RefreshStatus_6===u.gFWV(u)||u.gFWV(u)===PART8_C.RefreshStatus_8)return
if(u.Va$)return
if(d===0)u.sFWV(0,PART8_C.RefreshStatus_0)
x=u.j3$
if(Math.max(x.gIv()-x.gkX(),0)===0&&u.a.c===PART8_C.RefreshStyle_3)u.j3$.r.MB(!1)
u.lG$.toString
x=u.j3$.k1
x=x instanceof N.GU8||x instanceof N.Zv
if(x){x=u.C7$.a.x
if(x&&d>=80)u.sFWV(0,PART8_C.RefreshStatus_1)
else if(x)u.sFWV(0,PART8_C.RefreshStatus_0)
x=u.C7$.a
w=x.r
if(w){u.lG$.toString
v=d>=150}else v=!1
if(v)u.sFWV(0,PART8_C.RefreshStatus_5)
else if(w&&!x.x)u.sFWV(0,PART8_C.RefreshStatus_0)}else if(u.j3$.k1 instanceof N.ei){if(PART8_C.RefreshStatus_1===u.gFWV(u)){u.Va$=!0
u.Lif(0)
u.fzC().W7(0,new PART8.Jgn(u),y.P)}if(u.gFWV(u)===PART8_C.RefreshStatus_5){u.Va$=!0
u.Lif(0)
if(u.c==null)return
u.sFWV(0,PART8_C.RefreshStatus_6)}}},
BCV(){var x,w=this
if(w.c==null)return
w.Lif(0)
if(w.gFWV(w)===PART8_C.RefreshStatus_0||w.gFWV(w)===PART8_C.RefreshStatus_1){w.Va$=!1
w.C4m()
if(w.gFWV(w)===PART8_C.RefreshStatus_0)w.C7$.Sg(!0)}if(w.gFWV(w)===PART8_C.RefreshStatus_3||w.gFWV(w)===PART8_C.RefreshStatus_4)w.H1t().W7(0,new PART8.FVg(w),y.P)
else if(w.gFWV(w)===PART8_C.RefreshStatus_2){if(!w.Va$){w.Va$=!0
w.fzC()}w.lG$.toString
x=w.C7$.a.y
if(x!=null)x.$0()}else if(w.gFWV(w)===PART8_C.RefreshStatus_6){w.Va$=!0
w.C7$.Sg(!1)
$.z.z$.push(new PART8.AyK(w))}else if(w.gFWV(w)===PART8_C.RefreshStatus_8){w.Va$=!1
w.C7$.Sg(!1)
w.Lif(0)
x=w.C7$.a.Q
if(x!=null)x.$1(!1)}else if(w.gFWV(w)===PART8_C.RefreshStatus_7){x=w.C7$
x.toString
w.lG$.toString
x.Sg(!0)}w.eLk(w.gFWV(w))},
fzC(){return N.iv(null,y.H)},
H1t(){return N.dT(this.a.f,null,y.H)},
rCu(){return!0},
C4m(){},
wgb(d,e){var x=this,w=x.a.e,v=x.JTf(e,x.gFWV(x)),u=x.rCu()&&N.G0I(e).a.c===C.AxisDirection_0?10:0,t=x.Va$,s=x.gFWV(x)===PART8_C.RefreshStatus_7||x.gFWV(x)===PART8_C.RefreshStatus_6||x.gFWV(x)===PART8_C.RefreshStatus_8?x.C7$.f:x.a.d
return new PART8.QVC(s,t,x.a.c,w,new PART8.rwN(u,v,null),null)}}
PART8.Tf9.prototype={
EX(){var x=this.j3$,w=x.cx
w.toString
x=x.Q
x.toString
return Math.max(w-x,0)},
V2Y(){var x=this
x.setState(new PART8.xiU(x))
x.e=!1
x.L10().W7(0,new PART8.HKg(x),y.P)},
RP(){return N.dT(N.xC(0,0,0,0,0,0),null,y.z)},
fPy(){if(!this.Va$)return
this.RP().W7(0,new PART8.NkG(this),y.P)},
Xeo(){var x,w=this,v=w.j3$,u=v.Q
u.toString
x=v.cx
x.toString
w.lG$.toString
if(u-x<=15&&Math.max(v.gIv()-v.gkX(),0)>2&&w.e){w.lG$.toString
v=w.gFWV(w)
if(v===PART8_C.LoadStatus_3)return!1
if(w.gFWV(w)!==PART8_C.LoadStatus_1&&w.j3$.gKhG()===C.ED)return!1
return!0}return!1},
BCV(){var x,w=this
if(w.c==null||w.d)return
w.Lif(0)
if(w.gFWV(w)===PART8_C.LoadStatus_0||w.gFWV(w)===PART8_C.LoadStatus_4||w.gFWV(w)===PART8_C.LoadStatus_3){if(w.j3$.k1.gWt()<0&&w.f===PART8_C.LoadStatus_2&&!w.j3$.gbL()&&y.W.b(w.j3$)){x=w.j3$
x.oz(new N.co(x))}w.fPy()}if(w.gFWV(w)===PART8_C.LoadStatus_2){if(!w.Va$)w.V2Y()
w.lG$.toString
x=w.C7$.a.z
if(x!=null)x.$0()
if(w.a.c===PART8_C.LoadStyle_2)w.Va$=!0}else if(!(w.j3$.k1 instanceof N.GU8))w.e=!1
w.f=w.gFWV(w)
w.eLk(w.gFWV(w))},
zaP(d){var x=this
if(x.c==null||x.d||PART8_C.LoadStatus_2===x.gFWV(x)||x.Va$)return
if(x.j3$.k1 instanceof N.GU8)if(x.Xeo())x.sFWV(0,PART8_C.LoadStatus_1)
else x.sFWV(0,x.f)
if(x.j3$.k1 instanceof N.ei){x.lG$.toString
if(x.Xeo())x.V2Y()}},
BIm(){var x=this
if(x.d)return
x.AxG()
x.kIP(x.EX())},
Z34(){var x=this,w=x.j3$
if(!w.id.a){if(x.d||x.gFWV(x)===PART8_C.LoadStatus_2||x.gFWV(x)===PART8_C.LoadStatus_3)return
if(x.Xeo())if(x.j3$.k1 instanceof N.co){x.lG$.toString
x.V2Y()}}else{w=w.k1
if(w instanceof N.GU8||w instanceof N.Zv)x.e=!0}},
Wtm(d){var x=this,w=x.j3$
if(w!=null)w.id.Au(0,x.gV1B())
d.id.nz(0,x.gV1B())
x.qL8(d)},
didChangeDependencies(){var x=this
x.hbR()
x.f=x.gFWV(x)},
dispose(d){var x=this.j3$
if(x!=null)x.id.Au(0,this.gV1B())
this.Lxq(0)},
wgb(d,e){var x,w,v,u=this
u.lG$.toString
x=u.a.c
if(x===PART8_C.LoadStyle_0)x=!0
else x=x===PART8_C.LoadStyle_1?!1:u.Va$
w=u.gFWV(u)
v=u.a.d
return new PART8.Rs4(!1,x,u.gFWV(u),v,w===PART8_C.LoadStatus_3,new N.avE(new PART8.TCS(u),null),null)}}
PART8.RC6.prototype={
sFWV(d,e){var x=this.CD$
if(x!=null)x.snw(0,e)},
gFWV(d){var x=this.CD$
return x==null?null:x.a},
Lif(d){if(this.c!=null)this.setState(new PART8.K6U())},
BIm(){if(this.c==null)return
var x=this.EX()
if(x<0)return
this.zaP(x)},
qrK(){var x=this,w=x.CD$
if(w!=null)w.Au(0,x.gVTm())
w=x.j3$
if(w!=null)w.Au(0,x.gjCF())
x.CD$=x.j3$=null},
RU8(){var x,w,v,u,t=this
t.lG$=t.c.f5(y.r)
t.C7$=t.c.W8(y.q)
x=N.Lh(t)
w=N.Kx(x.CT("RC6.V"))
x=x.CT("ov<RC6.V>?")
v=t.C7$
u=w===PART8_C.p7?x.a(v.a.ch.gh1()):x.a(v.a.ch.giH())
x=t.c
x.toString
x=N.G0I(x).d
x.toString
w=t.CD$
if(u!=w){if(w!=null)w.Au(0,t.gVTm())
t.CD$=u
if(u!=null)u.nz(0,t.gVTm())}w=t.j3$
if(x!==w){if(w!=null)w.Au(0,t.gjCF())
t.Wtm(x)
t.j3$=x
x.nz(0,t.gjCF())}},
Wtm(d){this.C7$.a.ch.HP(d)}}
PART8.mlR.prototype={
kIP(d){},
eLk(d){}}
PART8.u3w.prototype={
kIP(d){},
eLk(d){},
L10(){return N.iv(null,y.z)}}
PART8.ol0.prototype={
initState(){this.rb()},
dispose(d){this.qrK()
this.EWu(0)},
didChangeDependencies(){this.RU8()
this.hp()},
didUpdateWidget(d){this.RU8()
this.hd(d)}}
PART8.y2N.prototype={}
PART8.xvw.prototype={
initState(){var x=this.c.W8(y.q)
if(x!=null){x=x.a.ch.gh1()
if(x!=null)x.snw(0,PART8_C.RefreshStatus_0)}this.rb()},
dispose(d){this.qrK()
this.EWu(0)},
didChangeDependencies(){this.RU8()
this.hp()},
didUpdateWidget(d){this.RU8()
this.hd(d)}}
PART8.wbs.prototype={}
PART8.Zs6.prototype={
KV5(d){var x=this
return new PART8.Zs6(x.b,x.c,x.d,x.e,x.f,x.r,!0,!1,x.z,x.Q,x.cqD(d))},
dKw(d){var x={}
if(d==null)return null
x.a=null
d.tf(new PART8.bPC(x,this))
return x.a},
EOE(d){if(this.a instanceof N.NeverScrollableScrollPhysics)return!1
return!0},
gbx(d){if(this.Q===0)return PART8_C.N0
else return PART8_C.QV},
Mya(d,e){var x,w,v,u,t,s,r,q,p,o=this
if(o.ch==null){x=o.z
x=x.gbM(x)
if(x==null)x=null
else{x=x.r.c
x.toString}o.ch=o.dKw(x)}x=o.z
if(x.gh1().a===PART8_C.RefreshStatus_7){if(e>0)return o.a.Mya(d,e)}else{if(e>0){w=o.ch
w=!((w==null?null:w.MA$) instanceof PART8.Xo8)}else w=!1
if(!w)if(e<0){w=o.ch
w=!((w==null?null:w.ph$) instanceof PART8.f5Y)}else w=!1
else w=!0
if(w)return o.a.Mya(d,e)}if(d.gbL()||x.gh1().a===PART8_C.RefreshStatus_7){w=d.z
w.toString
v=d.cx
v.toString
u=Math.max(w-v,0)
if(x.gh1().a===PART8_C.RefreshStatus_7)x=0
else{x=d.Q
x.toString}t=Math.max(v-x,0)
s=Math.max(u,t)
if(!(u>0&&e<0))r=t>0&&e>0
else r=!0
x=d.cy
if(r){x.toString
q=0.52*Math.pow(1-(s-Math.abs(e))/x,2)}else{x.toString
q=0.52*Math.pow(1-s/x,2)}p=J.zD(e)
x=PART8.kBB(s,Math.abs(e),q)
return p*x*o.r}return o.tA(d,e)},
JZ(d,e){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i=this,h=i.ch
if(h==null){h=i.z
h=h.gbM(h)
if(h==null)h=null
else{h=h.r.c
h.toString}h=i.ch=i.dKw(h)}x=d.z
x.toString
w=d.Q
w.toString
v=x===w
x=h==null
u=x?!1:h.MA$ instanceof PART8.Xo8
t=x?!1:h.ph$ instanceof PART8.f5Y
h=i.z
if(h.gh1().a===PART8_C.RefreshStatus_7){x=d.cx
x.toString
if(x-e>0)return i.a.JZ(d,e)}else{x=d.cx
x.toString
x-=e
if(!(x>0&&!u))x=x<0&&!t
else x=!0
if(x)return i.a.JZ(d,e)}if(u){s=y.A.a(i.ch.MA$)
r=s.HV?0:s.vk}else r=0
if(t){q=y.C.a(i.ch.ph$)
if(!(!v&&q.k4.a!==0)){if(v)if(h.ghK()===PART8_C.LoadStatus_3){h.gbM(h).r.c.f5(y.r).toString
x=!0}else x=!1
else x=!1
if(!x)if(v){h=h.gbM(h).r.c.f5(y.r)==null&&null
h=h===!0}else h=!1
else h=!0}else h=!0
p=h?0:q.ol}else p=0
h=d.z
h.toString
x=i.b
o=h-x-r
h=d.Q
h.toString
w=i.c
p.toString
n=h+w+p
m=d.k1
if(m instanceof N.ei){l=i.d
if(l!==1/0){k=-l
if(e<k){j=d.cx
j.toString
j=k<=j
k=j}else k=!1
if(k)return e+l}l=i.e
if(l!==1/0){k=d.cx
k.toString
j=l+h
if(k<j&&j<e)return e-l-h}}h=x!==1/0
if(h)if(e<o){x=d.cx
x.toString
x=o<x}else x=!1
else x=!1
if(x)return e-o
x=w!==1/0
if(x){w=d.cx
w.toString
w=w<n&&n<e}else w=!1
if(w)return e-n
if(m instanceof N.GU8){if(h){h=d.cx
h.toString
h=e<h&&h<=o}else h=!1
if(h){h=d.cx
h.toString
return e-h}if(x){h=d.cx
h.toString
h=n<=h&&h<e}else h=!1
if(h){h=d.cx
h.toString
return e-h}}return 0},
DU(d,e){var x,w,v,u,t=this,s=t.ch
if(s==null){s=t.z
s=s.gbM(s)
if(s==null)s=null
else{s=s.r.c
s.toString}s=t.ch=t.dKw(s)}x=s==null
w=x?!1:s.MA$ instanceof PART8.Xo8
v=x?!1:s.ph$ instanceof PART8.f5Y
s=t.z
if(s.gh1().a===PART8_C.RefreshStatus_7){if(e<0)return t.a.DU(d,e)}else if(!d.gbL()){if(!(e<0&&!w))x=e>0&&!v
else x=!0
if(x)return t.a.DU(d,e)}if(d.gIv()>0&&s.gh1().a===PART8_C.RefreshStatus_7||d.gbL()){x=d.gIv()
u=d.gkX()
s=s.gh1().a===PART8_C.RefreshStatus_7?0:d.geL()
return N.fgQ(u,x,t.f,t.gDt(),s,e*0.91)}return t.rK(d,e)}}
PART8.QVC.prototype={
Xb(d){var x=this,w=new PART8.Xo8(x.r,x.e,x.x,x.f,null,N.amA())
w.gup()
w.gLX()
w.fr=!1
w.swz(null)
w.swz(null)
return w},
ls(d,e){var x=this,w=d.W8(y.q).a.ch.gh1().a
e.sDXE(x.e)
e.sRG0(x.f)
e.jq=d
e.eD=x.r
e.Ht=w===PART8_C.RefreshStatus_6||w===PART8_C.RefreshStatus_7||w===PART8_C.RefreshStatus_0
e.Ae()
e.ol=x.x}}
PART8.Xo8.prototype={
sDXE(d){if(d===this.vk)return
this.vk=d
this.Ae()},
sRG0(d){var x=this
if(d===x.HV)return
if(!d)x.Ht=!0
x.HV=d
x.Ae()},
D2b(){this.YKO()},
gZJZ(){if(this.eD===PART8_C.RefreshStyle_3){var x=y.g.a(this.c).RZ.cx
x.toString
return Math.max(0,-x)}return 0},
yEC(d,e,f){var x,w=this
if(w.eD===PART8_C.RefreshStyle_3){x=y.g.a(w.c).RZ.cx
x.toString
w.nEe(0,e.nel(Math.min(0,x)),!0)}else w.nEe(0,e,!0)},
K1t(){var x,w,v,u,t,s,r,q,p=this,o=null
if(p.Ht){N.G0I(N.mk(p.jq,"context")).d.k1.C2()
p.Ht=!1}x=p.HV?1:0
w=x*p.vk
if(p.eD!==PART8_C.RefreshStyle_3){x=p.cf
if(w!==x){p.k4=N.By2(o,!1,o,o,0,0,0,0,0,w-x,o)
p.cf=w
return}}x=y.S
v=x.a(N.jU.prototype.gHv.call(p)).f<0||w>0
u=y.g.a(p.c).RZ.cx
u.toString
t=-u
u=p.eD
s=p.Ik$
if(u===PART8_C.RefreshStyle_2){s.toString
s.yEC(0,x.a(N.jU.prototype.gHv.call(p)).rgS(Math.max(0,t+w)),!0)}else{s.toString
s.yEC(0,x.a(N.jU.prototype.gHv.call(p)).NVf(),!0)}u=x.a(N.jU.prototype.gHv.call(p)).a===C.AxisDirection_0||x.a(N.jU.prototype.gHv.call(p)).a===C.AxisDirection_2
s=p.Ik$
r=u?s.rx.b:s.rx.a
if(v){u=x.a(N.jU.prototype.gHv.call(p)).a===C.AxisDirection_0||x.a(N.jU.prototype.gHv.call(p)).a===C.AxisDirection_2
s=p.Ik$
u=u?s.rx.b:s.rx.a
q=Math.min(Math.max(Math.max(u,w)-x.a(N.jU.prototype.gHv.call(p)).d,0),x.a(N.jU.prototype.gHv.call(p)).r)
switch(p.eD){case PART8_C.RefreshStyle_0:u=x.a(N.jU.prototype.gHv.call(p))
p.k4=N.By2(o,t<r,q,Math.min(q,Math.max(w-x.a(N.jU.prototype.gHv.call(p)).d,0)),q,0,q,-r-u.d+w,w,o,o)
break
case PART8_C.RefreshStyle_2:u=x.a(N.jU.prototype.gHv.call(p))
p.k4=N.By2(o,!1,o,Math.max(w-x.a(N.jU.prototype.gHv.call(p)).d,0),q,0,q,-t-u.d,w,o,o)
break
case PART8_C.RefreshStyle_1:u=Math.min(-t-x.a(N.jU.prototype.gHv.call(p)).d,-r-x.a(N.jU.prototype.gHv.call(p)).d+w)
p.k4=N.By2(o,t<r,o,Math.min(q,Math.max(w-x.a(N.jU.prototype.gHv.call(p)).d,0)),q,0,q,u,w,o,o)
break
case PART8_C.RefreshStyle_3:p.k4=N.By2(o,!0,o,o,0,0,0,x.a(N.jU.prototype.gHv.call(p)).a===C.AxisDirection_0||x.a(N.jU.prototype.gHv.call(p)).y===C.AxisDirection_3?r:0,0,o,!0)
break
case null:break}u=p.Ik$
u.toString
x=x.a(N.jU.prototype.gHv.call(p))
s=p.k4
s.toString
p.jSR(u,x,s)}else p.k4=C.LA},
It(d,e){var x=this.Ik$
x.toString
d.u3i(x,new N.Offset(e.a,e.b+this.ol))},
kl(d,e){}}
PART8.Rs4.prototype={
Xb(d){var x=this,w=new PART8.f5Y(x.y,!1,x.r,null,N.amA())
w.gup()
w.gLX()
w.fr=!1
w.swz(null)
w.Ht=x.f
w.st3W(x.x)
w.swz(null)
return w},
ls(d,e){var x=this
e.vk=x.r
e.sRG0(x.f)
e.st3W(x.x)
e.eD=x.y
e.jq=!1}}
PART8.f5Y.prototype={
st3W(d){if(d===this.ol)return
this.ol=d
this.Ae()},
sRG0(d){if(d===this.Ht)return
this.Ht=d
this.Ae()},
IfC(d){var x,w,v,u=y.K.a(this.c),t=u.MA$,s=d.e
for(x=N.Lh(u).CT("pvS.1");t!==this;){if(t instanceof PART8.Xo8){w=s-t.k4.a
s=w
break}v=t.e
v.toString
t=x.a(v).UH$}return s>d.z},
GI2(d,e,f){var x,w=this
if(f){if(e)return d
return 0}else{x=y.S
if(e){x=Math.max(x.a(N.jU.prototype.gHv.call(w)).z-x.a(N.jU.prototype.gHv.call(w)).e,0)
d.toString
return x+d}else return Math.max(x.a(N.jU.prototype.gHv.call(w)).z-x.a(N.jU.prototype.gHv.call(w)).e,0)}},
K1t(){var x,w,v,u,t,s,r=this,q=r.Ik$
if(q==null){r.k4=C.LA
return}x=y.S
q.toString
q.yEC(0,x.a(N.jU.prototype.gHv.call(r)).NVf(),!0)
q=N.j27(x.a(N.jU.prototype.gHv.call(r)).a)
w=r.Ik$
v=q===C.Axis_1?w.rx.b:w.rx.a
u=r.OL(x.a(N.jU.prototype.gHv.call(r)),0,v)
t=r.LrP(x.a(N.jU.prototype.gHv.call(r)),0,v)
q=r.Ht
q.toString
q=!q||!r.IfC(x.a(N.jU.prototype.gHv.call(r)))?0:r.ol
w=r.Ht
w.toString
w=!w||!r.IfC(x.a(N.jU.prototype.gHv.call(r)))?r.ol:0
s=x.a(N.jU.prototype.gHv.call(r)).a===C.AxisDirection_0||x.a(N.jU.prototype.gHv.call(r)).a===C.AxisDirection_3
w=r.GI2(w,s,r.IfC(x.a(N.jU.prototype.gHv.call(r)))||r.eD)
w.toString
r.k4=N.By2(t,!0,u,null,v,0,u,w,q,null,!0)
q=r.Ik$
q.toString
x=x.a(N.jU.prototype.gHv.call(r))
w=r.k4
w.toString
r.jSR(q,x,w)}}
PART8.O06.prototype={
Xb(d){var x=new PART8.KeT(null,N.amA())
x.gup()
x.gLX()
x.fr=!1
x.swz(null)
return x}}
PART8.KeT.prototype={
K1t(){var x,w,v,u,t,s=this,r=null,q=s.Ik$
if(q==null){s.k4=C.LA
return}x=y.S
q.yEC(0,x.a(N.jU.prototype.gHv.call(s)).rgS(1111111),!0)
switch(N.j27(x.a(N.jU.prototype.gHv.call(s)).a).a){case 0:w=s.Ik$.rx.a
break
case 1:w=s.Ik$.rx.b
break
default:w=r}if(w===1111111){q=s.Ik$
q.toString
q.yEC(0,x.a(N.jU.prototype.gHv.call(s)).rgS(x.a(N.jU.prototype.gHv.call(s)).z),!0)}switch(N.j27(x.a(N.jU.prototype.gHv.call(s)).a).a){case 0:w=s.Ik$.rx.a
break
case 1:w=s.Ik$.rx.b
break}v=s.OL(x.a(N.jU.prototype.gHv.call(s)),0,w)
u=s.LrP(x.a(N.jU.prototype.gHv.call(s)),0,w)
s.k4=N.By2(u,w>x.a(N.jU.prototype.gHv.call(s)).r||x.a(N.jU.prototype.gHv.call(s)).d>0,v,r,w,0,v,0,w,r,r)
q=s.Ik$
q.toString
x=x.a(N.jU.prototype.gHv.call(s))
t=s.k4
t.toString
s.jSR(q,x,t)}}
PART8.KrM.prototype={
Z(d){return"RefreshStatus."+this.b}}
PART8.kj0.prototype={
Z(d){return"LoadStatus."+this.b}}
PART8.ADR.prototype={
Z(d){return"RefreshStyle."+this.b}}
PART8.GzT.prototype={
Z(d){return"LoadStyle."+this.b}}
PART8.SmartRefresher.prototype={
wga(){var x=null,w=N.HA()===C.TargetPlatform_2?PART8.X4(x,x,C.Xu,PART8_C.QJ,x,PART8_C.Il,x,60,PART8_C.IconPosition_0,PART8_C.Mt,x,x,x,PART8_C.RefreshStyle_0,x,x,PART8_C.XF,x,15,PART8_C.xG,x):new PART8.ACY(PART8_C.RefreshStyle_3,80,0,C.Ng,x)
return new PART8.eDm(w,PART8.PQ(PART8_C.ZG,x,C.TJ,PART8_C.Il,x,60,PART8_C.IconPosition_0,PART8_C.Ti,x,x,PART8_C.LoadStyle_0,x,x,x,x,x,x,15,PART8_C.xG),C.ed)}}
PART8.eDm.prototype={
jO(d,e){var x,w,v,u,t,s,r,q,p,o,n,m,l=this,k=null
if(!(e instanceof N.BouncingScrollPhysics))if(e instanceof N.AlwaysScrollableScrollPhysics){x=l.c
x.toString
x=N.af6(x)
w=l.c
w.toString
w=N.PR(x.NU(w))===PART8_C.QV
v=w}else v=!1
else v=!0
x=d==null
w=x?k:1
if(w==null)w=1
u=x?k:PART8_C.b4
if(u==null)u=PART8_C.b4
t=l.a.ch
s=!x||k
r=l.e?0:1
x=x&&k
q=v?1/0:0
p=v?1/0:60
o=v?1/0:0
n=v?1/0:0
m=!l.r?new N.NeverScrollableScrollPhysics(k):e
return l.d=new PART8.Zs6(p,q,o,n,u,w,s!==!1,x===!0,t,r,k).KV5(m)},
nGG(a2,a3,a4){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,a0=this,a1=null
if(!(a2 instanceof N.Cnk)){x=a0.a
w=x.dy
v=x.fx
u=x.cy
t=x.fy
s=x.db
r=x.dx
q=x.go
p=x.fr
if(a2 instanceof N.mRd){if(w==null)w=a2.f
if(v==null)v=a2.ch
o=a2.a
if(t==null)t=a2.cx
if(s==null)s=a2.d
if(q==null)q=a2.cy
if(u==null)u=a2.c
if(p==null)p=a2.r
n=a2.z
m=a2.Q
l=a2.db
k=a2.dx
j=a2.dy
if(r==null)r=a2.e}else{j=a1
k=j
l=k
m=l
n=m
o=n}x=u==null?C.Axis_1:u
i=j==null?C.Clip_1:j
h=l==null?C.ScrollViewKeyboardDismissBehavior_0:l
g=m==null?0:m
f=a0.jO(a4,p==null?new N.AlwaysScrollableScrollPhysics(a1):p)
a3.toString
e=q==null?C.DragStartBehavior_1:q
d=N.Nu(g,v,n,i,r,e,o,h,f,w,k,s===!0,new PART8.fR6(a1),x,t,!1,a3)}else{x=a2.e
x=a0.jO(a4,x==null?new N.AlwaysScrollableScrollPhysics(a1):x)
i=a2.d
h=a2.c
g=a2.y
d=N.RHM(h,i,a2.z,!1,a1,x,a1,new PART8.fR6(a1),g,new PART8.Mms(a0,a2,a4))}return d},
FAw(){var x=this.c.f5(y.r)
if(x==null||this.d==null)return!1
x.toString
this.d.toString
return!0},
Sg(d){if(this.r===d)return
this.setState(new PART8.U2(this,d))},
didUpdateWidget(d){var x=this.a.ch,w=d.ch
if(x!==w){x=x.gh1()
x.toString
x.snw(0,w.gh1().a)
x=this.a.ch.giH()
x.toString
x.snw(0,w.giH().a)}this.hd(d)},
didChangeDependencies(){var x=this
x.hp()
if(x.FAw())x.e=!x.e},
initState(){var x=this
if(x.a.ch.gQr())$.z.z$.push(new PART8.vrX(x))
x.a.ch.a=x
x.rb()},
dispose(d){var x,w=this.a.ch
w.a=null
x=w.gbM(w)
if(x!=null)x.id.Au(0,w.gJg())
this.EWu(0)},
wgb(d,e){var x,w,v,u,t=this,s=null,r={},q=e.f5(y.r)
r.a=null
x=t.a.c
if(x instanceof N.mRd)if(x instanceof N.fbC){w=x.tTt(e)
x=x.fx
v=y.p
u=x!=null?N.J([new N.SliverPadding(x,w,s)],v):N.J([w],v)}else u=N.PW(x.z6x(e),!0,y.l)
else if(!(x instanceof N.Cnk))u=N.J([new PART8.O06(x==null?N.jQB(s,s,C.Clip_0,s,s,s,s,s,s,s,s,s,s,s):x,s)],y.p)
else u=s
x=t.a
if(x.x||x.r)if(u!=null){x=x.d
if(x==null)x=s
C.Nm.aP(u,0,x==null?t.x:x)}x=t.a
if(x.f)if(u!=null){x=x.e
if(x==null)x=s
u.push(x==null?t.y:x)}x=r.a=t.nGG(t.a.c,u,q)
if(q==null){x.toString
r.a=new PART8.vYQ(x,x,s)}return new N.avE(new PART8.kQQ(r,t),s)}}
PART8.b3.prototype={
gVt(){var x=this.gh1()
return x==null?null:x.a},
ghK(){var x=this.giH()
return x==null?null:x.a},
gHI(){var x=this.gh1()
return(x==null?null:x.a)===PART8_C.RefreshStatus_2},
gV0(){var x=this.gh1()
if((x==null?null:x.a)!==PART8_C.RefreshStatus_7){x=this.gh1()
if((x==null?null:x.a)!==PART8_C.RefreshStatus_6){x=this.gh1()
x=(x==null?null:x.a)===PART8_C.RefreshStatus_8}else x=!0}else x=!0
return x},
gqq(){var x=this.giH()
return(x==null?null:x.a)===PART8_C.LoadStatus_2},
p(d,e,f){var x=f==null?PART8_C.RefreshStatus_0:f,w=y.Z
this.sh1(new PART8.ov(x,N.I(0,null,!1,w),y.i))
x=d==null?PART8_C.LoadStatus_0:d
this.siH(new PART8.ov(x,N.I(0,null,!1,w),y.b))},
HP(d){var x=this,w=x.gbM(x)
if(w!=null)w.id.Au(0,x.gJg())
x.sbM(0,d)
x.gbM(x).id.nz(0,x.gJg())},
vw(d,e){var x={}
x.a=null
d.tf(new PART8.kD(x,this,e))
return x.a},
R7B(){var x,w=this
if(w.gbM(w)!=null&&w.gbM(w).gbL()){x=w.gbM(w)
if(x!=null){x=x.k1
if(x!=null)x.C2()}}},
eU(d,e,f,g){var x,w,v=this,u=null
if(v.gHI())return N.iv(u,y.H)
x=v.gbM(v).r.c
x.toString
w=v.vw(x,PART8_C.Ii)
if(w==null||v.a==null)return u
x=w.TB
x.toString
y.X.a(x).Va$=!0
if(g&&v.a.c!=null)v.a.Sg(!1)
x=y.z
if(g)return N.dT(C.kA,u,x).W7(0,new PART8.wV(v,e,d,f,w),y.H)
else N.iv(u,x).W7(0,new PART8.pX(v),y.P)},
hyZ(){return this.eU(C.t0,C.Ng,!0,!0)},
Sf(d,e){this.gh1().snw(0,PART8_C.RefreshStatus_6)
return N.dT(C.kA,null,y.z).W7(0,new PART8.DY(this,e,d),y.H)},
Ep(d,e,f,g){var x,w,v,u=this,t=null
if(u.gqq())return N.iv(t,y.H)
x=u.gbM(u).r.c
x.toString
w=u.vw(x,PART8_C.iZ)
if(w==null||u.a==null)return t
x=w.TB
x.toString
y.t.a(x).Va$=!0
if(g&&u.a.c!=null)u.a.Sg(!1)
x=y.z
v=y.H
if(g)return N.dT(C.kA,t,x).W7(0,new PART8.Af(u,e,d,f,w),v)
else return N.iv(t,x).W7(0,new PART8.S5(u),v)},
mN(d){var x=this.gh1()
if(x!=null)x.snw(0,PART8_C.RefreshStatus_3)
if(d)this.CO()},
vY(d,e){var x=this.gh1()
if(x!=null)x.snw(0,PART8_C.RefreshStatus_8)
$.z.z$.push(new PART8.on(this,e,d))
return null},
L92(){return this.vY(C.t0,C.Ng)},
O2(){var x=this.gh1()
if(x!=null)x.snw(0,PART8_C.RefreshStatus_4)},
u2(){var x=this.gh1()
if(x!=null)x.snw(0,PART8_C.RefreshStatus_0)},
dG(){$.z.z$.push(new PART8.ht(this))},
Fv(){$.z.z$.push(new PART8.eq(this))},
AX(){$.z.z$.push(new PART8.x4(this))},
CO(){var x=this.giH()
if((x==null?null:x.a)===PART8_C.LoadStatus_3)this.giH().snw(0,PART8_C.LoadStatus_0)},
dispose(d){var x=this
x.gh1()
x.giH()
x.sh1(null)
x.siH(null)},
gh1(){return this.b},
giH(){return this.c},
gbM(d){return this.d},
gQr(){return this.e},
sh1(d){return this.b=d},
siH(d){return this.c=d},
sbM(d,e){return this.d=e}}
PART8.vYQ.prototype={
bhB(d){return!1},
gwz(){return this.f}}
PART8.ov.prototype={
snw(d,e){if(this.a==e)return
this.a=e
this.Ca()},
ED(d){if(this.a===d)return
this.a=d},
Z(d){return"<optimized out>#"+N.LG(this)+"("+N.Ej(this.a)+")"}}
PART8.fR6.prototype={
gQVi(){return N.Ld([C.PointerDeviceKind_0,C.PointerDeviceKind_1,C.PointerDeviceKind_2,C.PointerDeviceKind_3],y.B)}}
var z=a.updateTypes(["~()","@(T8C<@,@>)","CP5(CP5)","b8<~>?({curve:d2Z,duration:Duration,needCallback:a2j,needMove:a2j})","~(a2j,a2j,Duration,d2Z,~(),~(qU))","~(Duration,d2Z,~(),~(qU))","~(Gsk,Offset)","~(FMk)","b8<~>({curve:d2Z,duration:Duration})","~({resetFooterState:a2j})","b8<~>?({curve:d2Z,duration:Duration})","~(a2j)","qU()","SmartRefresher(T8C<@,@>)","b3(a2j?,KrM?,kj0?)","ClassicHeader(T8C<@,@>)","ClassicFooter(T8C<@,@>)","CustomHeader(T8C<@,@>)","CustomFooter(T8C<@,@>)"])
PART8.NKO.prototype={
$2(d,e){var x,w,v,u="_controller",t=this.a,s=$.t4i(),r=N.mk(t.d,u)
r=s.At(0,r.gnw(r))
s=$.XWT()
x=N.mk(t.d,u)
x=s.At(0,x.gnw(x))
s=$.pp()
w=N.mk(t.d,u)
w=s.At(0,w.gnw(w))
s=$.Vaf()
v=N.mk(t.d,u)
return t.TF(d,1.05*r,x,w,s.At(0,v.gnw(v)))},
$S:43}
PART8.kMJ.prototype={
$2(d,e){return this.a.Ik$.VN(d,e)},
$S:12}
PART8.cl.prototype={
$1(d){this.a.$0()},
$S:16}
PART8.Fl.prototype={
$1(d){this.a.$1(N.Ej(d))},
$S:5}
PART8.Hq.prototype={
$1(d){this.a.$0()},
$S:16}
PART8.KE.prototype={
$1(d){this.a.$1(N.Ej(d))},
$S:5}
PART8.Wq.prototype={
$1(d){this.a.$0()},
$S:16}
PART8.Ml.prototype={
$1(d){this.a.$1(N.Ej(d))},
$S:5}
PART8.jrg.prototype={
$0(){var x,w=this.a
if(w.c!=null){x=w.ch.cx
x.toString
x=x<=0}else x=!1
if(x)w.setState(new PART8.Var())},
$S:0}
PART8.Var.prototype={
$0(){},
$S:0}
PART8.Jgn.prototype={
$1(d){var x=this.a
if(x.c==null)return
x.sFWV(0,PART8_C.RefreshStatus_2)},
$S:16}
PART8.FVg.prototype={
$1(d){var x,w=this.a
if(w.c==null)return
w.Va$=!1
if(w.gFWV(w)===PART8_C.RefreshStatus_3||w.gFWV(w)===PART8_C.RefreshStatus_4){x=w.C7$
x.toString
w.lG$.toString
x.Sg(!1)}w.Lif(0)
$.z.z$.push(new PART8.GU3(w))},
$S:16}
PART8.GU3.prototype={
$1(d){var x,w,v=this.a
if(v.c==null)return
if(v.a.c===PART8_C.RefreshStyle_3){x=v.j3$
w=x.cx
w.toString
if(w<0)x.G8(0)
v.sFWV(0,PART8_C.RefreshStatus_0)}else{x=v.j3$
w=x.cx
w.toString
if(!(w<0))v.sFWV(0,PART8_C.RefreshStatus_0)
else x.k1.ghI().S0(0)}},
$S:4}
PART8.AyK.prototype={
$1(d){var x=this.a
if(x.c==null)return
x.j3$.k1.Id()
x.j3$.KV(0,C.t0,C.Ng).wM(new PART8.wqs(x))
x=x.C7$.a.Q
if(x!=null)x.$1(!0)},
$S:4}
PART8.wqs.prototype={
$0(){this.a.sFWV(0,PART8_C.RefreshStatus_7)},
$S:11}
PART8.xiU.prototype={
$0(){this.a.Va$=!0},
$S:0}
PART8.HKg.prototype={
$1(d){var x=this.a
if(x.c==null)return
x.sFWV(0,PART8_C.LoadStatus_2)},
$S:5}
PART8.NkG.prototype={
$1(d){var x=this.a,w=x.c
if(w==null)return
N.G0I(w).d.KF(0.00001)
$.z.z$.push(new PART8.ApV(x))
x.setState(new PART8.WtH(x))},
$S:5}
PART8.ApV.prototype={
$1(d){var x,w=this.a
if(w.c!=null){x=w.j3$
x=(x==null?null:x.gbL())===!0}else x=!1
if(x)w.j3$.k1.ghI().S0(0)},
$S:4}
PART8.WtH.prototype={
$0(){this.a.Va$=!1},
$S:0}
PART8.TCS.prototype={
$2(d,e){var x=null,w=this.a
C.jn.IV(1/0,e.a,e.b)
w.d=C.jn.IV(1/0,e.c,e.d)===0
return N.TH9(C.HitTestBehavior_1,w.JTf(d,w.gFWV(w)),C.DragStartBehavior_1,!1,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,new PART8.igW(w),x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x,x)},
$S:610}
PART8.igW.prototype={
$0(){var x=this.a.a.e
if(x!=null)x.$0()},
$S:0}
PART8.K6U.prototype={
$0(){},
$S:0}
PART8.bPC.prototype={
$1(d){var x=d.gZA(),w=this.a
if(x instanceof N.nh)w.a=x
else w.a=this.b.dKw(d)},
$S:22}
PART8.Mms.prototype={
$2(d,e){var x=y.a.a(this.b.f.$2(d,e)),w=this.a,v=w.a
if(v.x){v=v.d
if(v==null)v=null
if(v==null)v=w.x
J.frc(x.c,0,v)}v=w.a
if(v.f){v=v.e
if(v==null)v=null
w=v==null?w.y:v
J.Xe(x.c,w)}return x},
$S:172}
PART8.U2.prototype={
$0(){this.a.r=this.b},
$S:0}
PART8.vrX.prototype={
$1(d){var x=this.a
if(x.c!=null)x.a.ch.hyZ()},
$S:4}
PART8.kQQ.prototype={
$2(d,e){var x
C.jn.IV(1/0,e.a,e.b)
this.b.f=C.jn.IV(1/0,e.c,e.d)
x=this.a.a
x.toString
return x},
$S:98}
PART8.kD.prototype={
$1(d){var x,w=this,v=w.c
if(v===PART8_C.Ii){if(d.gcV() instanceof PART8.Rr)w.a.a=y.s.a(d)}else if(d.gcV() instanceof PART8.Ds)w.a.a=y.s.a(d)
x=w.a
if(x.a==null)x.a=w.b.vw(d,v)},
$S:22}
PART8.wV.prototype={
$1(d){var x=0,w=N.FX(y.H),v=this,u,t,s
var $async$$1=N.lz(function(e,f){if(e===1)return N.f(f,w)
while(true)switch(x){case 0:t=v.a
s=t.gbM(t)
if(s==null)t=null
else{u=t.gbM(t).z
u.toString
t=s.KV(u-0.0001,v.c,v.b).W7(0,new PART8.W6(t,v.d,v.e),y.P)}x=2
return N.j(t,$async$$1)
case 2:return N.k(null,w)}})
return N.i($async$$1,w)},
$S:90}
PART8.W6.prototype={
$1(d){var x=this.a,w=x.a
if(w!=null&&w.c!=null){w.Sg(!0)
if(this.b)x.gh1().snw(0,PART8_C.RefreshStatus_2)
else{x.gh1().ED(PART8_C.RefreshStatus_2)
x=this.c.TB
if(x.c!=null)y.X.a(x).setState(new PART8.Gp())}}},
$S:16}
PART8.Gp.prototype={
$0(){},
$S:0}
PART8.pX.prototype={
$1(d){this.a.gh1().snw(0,PART8_C.RefreshStatus_2)},
$S:5}
PART8.DY.prototype={
$1(d){var x=0,w=N.FX(y.H),v=this,u,t
var $async$$1=N.lz(function(e,f){if(e===1)return N.f(f,w)
while(true)switch(x){case 0:u=v.a
t=u.gbM(u)
if(t==null)u=null
else{u=u.gbM(u).z
u.toString
u=t.KV(u,v.c,v.b)}x=2
return N.j(u,$async$$1)
case 2:return N.k(null,w)}})
return N.i($async$$1,w)},
$S:90}
PART8.Af.prototype={
$1(d){var x=0,w=N.FX(y.H),v=this,u,t,s
var $async$$1=N.lz(function(e,f){if(e===1)return N.f(f,w)
while(true)switch(x){case 0:t=v.a
s=t.gbM(t)
if(s==null)t=null
else{u=t.gbM(t).Q
u.toString
t=s.KV(u,v.c,v.b).W7(0,new PART8.NO(t,v.d,v.e),y.P)}x=2
return N.j(t,$async$$1)
case 2:return N.k(null,w)}})
return N.i($async$$1,w)},
$S:90}
PART8.NO.prototype={
$1(d){var x=this.a,w=x.a
if(w!=null&&w.c!=null){w.Sg(!0)
if(this.b)x.giH().snw(0,PART8_C.LoadStatus_2)
else{x.giH().ED(PART8_C.LoadStatus_2)
x=this.c.TB
if(x.c!=null)y.t.a(x).setState(new PART8.oS())}}},
$S:16}
PART8.oS.prototype={
$0(){},
$S:0}
PART8.S5.prototype={
$1(d){this.a.giH().snw(0,PART8_C.LoadStatus_2)},
$S:5}
PART8.on.prototype={
$1(d){var x=this.a
x.gbM(x).KV(0,this.c,this.b).wM(new PART8.qb(x))},
$S:4}
PART8.qb.prototype={
$0(){this.a.gh1().snw(0,PART8_C.RefreshStatus_0)},
$S:11}
PART8.ht.prototype={
$1(d){var x=this.a.giH()
if(x!=null)x.snw(0,PART8_C.LoadStatus_0)},
$S:4}
PART8.eq.prototype={
$1(d){var x=this.a.giH()
if(x!=null)x.snw(0,PART8_C.LoadStatus_4)},
$S:4}
PART8.x4.prototype={
$1(d){var x=this.a.giH()
if(x!=null)x.snw(0,PART8_C.LoadStatus_3)},
$S:4};(function aliases(){var x=PART8.f39.prototype
x.CDa=x.dispose
x=PART8.I6H.prototype
x.crj=x.fzC
x.H3i=x.H1t
x.qxH=x.C4m
x=PART8.Tf9.prototype
x.xef=x.RP
x=PART8.RC6.prototype
x.AxG=x.BIm
x.qL8=x.Wtm
x=PART8.mlR.prototype
x.rSh=x.kIP
x.ofn=x.eLk
x=PART8.u3w.prototype
x.Bpd=x.kIP
x.axr=x.eLk
x.C5=x.L10
x=PART8.ol0.prototype
x.Lxq=x.dispose
x.hbR=x.didChangeDependencies
x=PART8.xvw.prototype
x.eXk=x.initState
x.hNl=x.dispose
x.Lvi=x.didChangeDependencies
x.h0O=x.didUpdateWidget
x=PART8.b3.prototype
x.LY=x.dispose})();(function installTearOffs(){var x=a._instance_1u,w=a._instance_2u,v=a._static_1,u=a.installStaticTearOff,t=a.installInstanceTearOff,s=a._instance_0u,r=a._instance_0i
var q
x(q=PART8.ywS.prototype,"gTsy","n4G",2)
x(q,"gc9D","Emj",2)
x(q,"gL3E","MZD",2)
x(q,"gBhg","Gse",2)
w(q,"gDRK","oJj",6)
v(PART8,"kw","BEC",13)
v(PART8,"nR","MpY",1)
v(PART8,"U0","TWS",1)
v(PART8,"Su","VoD",1)
v(PART8,"N0","Gip",1)
u(PART8,"G7",3,null,["$3"],["refreshControllerInstance"],14,0)
v(PART8,"w5","rHt",1)
v(PART8,"WP","NPh",15)
v(PART8,"VO","tBY",16)
v(PART8,"YV","pqG",1)
v(PART8,"aT","bzM",17)
v(PART8,"Pw","Usd",18)
x(q=PART8.OctoRefreshController.prototype,"gva","HP",7)
t(q,"gUC",0,0,function(){return{curve:C.t0,duration:C.Ng,needCallback:!0,needMove:!0}},["$4$curve$duration$needCallback$needMove","$0","$2$curve$duration"],["eU","hyZ","jQp"],3,0,0)
t(q,"gVx",0,0,function(){return{curve:C.t0,duration:C.TJ,needCallback:!0,needMove:!0}},["$4$curve$duration$needCallback$needMove","$0","$2$curve$duration"],["Ep","RqZ","n83"],3,0,0)
t(q,"gvr",0,0,function(){return{curve:C.t0,duration:C.TJ}},["$2$curve$duration","$0"],["Sf","Iu4"],8,0,0)
t(q,"gGE",0,0,function(){return{resetFooterState:!1}},["$1$resetFooterState","$0"],["mN","bfK"],9,0,0)
t(q,"gCw",0,0,function(){return{curve:C.t0,duration:C.Ng}},["$2$curve$duration","$0"],["vY","L92"],10,0,0)
s(q,"gTz","O2",0)
s(q,"gD6","u2",0)
s(q,"gZV","dG",0)
s(q,"gXE","Fv",0)
s(q,"gyB","AX",0)
s(q,"gUj","CO",0)
r(q,"gm8","dispose",0)
t(q,"gvX",0,6,null,["$6"],["rha"],4,0,0)
t(q,"gtc",0,4,null,["$4"],["rhb"],5,0,0)
t(q,"gvZ",0,6,null,["$6"],["rhc"],4,0,0)
x(q,"gS2","rhd",11)
t(q,"gN9",0,4,null,["$4"],["rhe"],5,0,0)
s(q,"gUu","rhf",0)
s(q,"gGz","rhg",0)
s(q,"guk","rhi",0)
s(q,"gmn","rhj",0)
s(q,"gbk","rhk",0)
s(q,"gOd","rhl",0)
r(q,"gCR","Z",12)
s(q=PART8.I6H.prototype,"gjCF","BIm",0)
s(q,"gVTm","BCV",0)
s(q=PART8.Tf9.prototype,"gVTm","BCV",0)
s(q,"gjCF","BIm",0)
s(q,"gV1B","Z34",0)
s(PART8.RC6.prototype,"gjCF","BIm",0)
s(PART8.b3.prototype,"gJg","R7B",0)})();(function inheritance(){var x=a.mixinHard,w=a.mixin,v=a.inherit,u=a.inheritMany
v(PART8.VuK,N.Animatable)
u(N.Mh,[PART8.qwE,PART8.mV4,PART8.b3,PART8.RC6,PART8.mlR,PART8.u3w])
v(PART8.lmJ,N.UAP)
v(PART8.wIn,N.CircularProgressIndicator)
v(PART8.xvE,N.ky9)
u(N.E1N,[PART8.NKO,PART8.kMJ,PART8.TCS,PART8.Mms,PART8.kQQ])
v(PART8.ykS,N.Qc2)
v(PART8.ywS,PART8.ykS)
u(N.rUn,[PART8.rwN,PART8.QVC,PART8.Rs4,PART8.O06])
v(PART8.OctoRefreshController,PART8.b3)
u(N.Tp,[PART8.cl,PART8.Fl,PART8.Hq,PART8.KE,PART8.Wq,PART8.Ml,PART8.Jgn,PART8.FVg,PART8.GU3,PART8.AyK,PART8.HKg,PART8.NkG,PART8.ApV,PART8.bPC,PART8.vrX,PART8.kD,PART8.wV,PART8.W6,PART8.pX,PART8.DY,PART8.Af,PART8.NO,PART8.S5,PART8.on,PART8.ht,PART8.eq,PART8.x4])
u(N.cke,[PART8.Ela,PART8.KrM,PART8.kj0,PART8.ADR,PART8.GzT])
u(N.kX1,[PART8.Rr,PART8.Ds,PART8.SmartRefresher])
u(PART8.Rr,[PART8.ClassicHeader,PART8.CustomHeader,PART8.ACY])
u(N.wm,[PART8.xvw,PART8.ol0,PART8.eDm])
v(PART8.wbs,PART8.xvw)
v(PART8.I6H,PART8.wbs)
u(PART8.I6H,[PART8.Hyq,PART8.DyT,PART8.f39])
u(PART8.Ds,[PART8.ClassicFooter,PART8.CustomFooter])
v(PART8.y2N,PART8.ol0)
v(PART8.Tf9,PART8.y2N)
u(PART8.Tf9,[PART8.WYN,PART8.TpB])
v(PART8.nJ4,PART8.f39)
u(N.Ay3,[PART8.jrg,PART8.Var,PART8.wqs,PART8.xiU,PART8.WtH,PART8.igW,PART8.K6U,PART8.U2,PART8.Gp,PART8.oS,PART8.qb])
v(PART8.Zs6,N.jHf)
u(N.A35,[PART8.Xo8,PART8.f5Y,PART8.KeT])
v(PART8.vYQ,N.SI4)
v(PART8.ov,N.ChangeNotifier)
v(PART8.fR6,N.MaterialScrollBehavior)
x(PART8.ykS,N.AOA)
x(PART8.f39,N.lCH)
x(PART8.ol0,PART8.RC6)
w(PART8.y2N,PART8.u3w)
x(PART8.xvw,PART8.RC6)
w(PART8.wbs,PART8.mlR)})()
N.xbv(b.typeUniverse,JSON.parse('{"VuK":{"Animatable":["1"],"Animatable.T":"1"},"lmJ":{"rRE":[]},"wIn":{"kX1":[],"Widget":[]},"xvE":{"wm":["CircularProgressIndicator"],"DGe":[]},"ywS":{"Qc2":[],"AOA":["Qc2"],"jU":[],"F9":[],"Y3C":[]},"rwN":{"rUn":[],"rN9":[],"Widget":[]},"Ela":{"q8v":[]},"ClassicHeader":{"Rr":[],"kX1":[],"Widget":[]},"ClassicFooter":{"Ds":[],"kX1":[],"Widget":[]},"Hyq":{"I6H":["ClassicHeader"],"RC6":["ClassicHeader","KrM"],"wm":["ClassicHeader"],"RC6.V":"KrM"},"WYN":{"Tf9":["ClassicFooter"],"RC6":["ClassicFooter","kj0"],"wm":["ClassicFooter"],"RC6.V":"kj0"},"CustomHeader":{"Rr":[],"kX1":[],"Widget":[]},"CustomFooter":{"Ds":[],"kX1":[],"Widget":[]},"DyT":{"I6H":["CustomHeader"],"RC6":["CustomHeader","KrM"],"wm":["CustomHeader"],"RC6.V":"KrM"},"TpB":{"Tf9":["CustomFooter"],"RC6":["CustomFooter","kj0"],"wm":["CustomFooter"],"RC6.V":"kj0"},"ACY":{"Rr":[],"kX1":[],"Widget":[]},"nJ4":{"I6H":["ACY"],"RC6":["ACY","KrM"],"wm":["ACY"],"DGe":[],"RC6.V":"KrM"},"Rr":{"kX1":[],"Widget":[]},"Ds":{"kX1":[],"Widget":[]},"I6H":{"RC6":["1","KrM"],"wm":["1"]},"Tf9":{"RC6":["1","kj0"],"wm":["1"]},"Zs6":{"jHf":[]},"QVC":{"rUn":[],"rN9":[],"Widget":[]},"Xo8":{"lLS":[],"AOA":["Qc2"],"jU":[],"F9":[],"Y3C":[]},"Rs4":{"rUn":[],"rN9":[],"Widget":[]},"f5Y":{"lLS":[],"AOA":["Qc2"],"jU":[],"F9":[],"Y3C":[]},"O06":{"rUn":[],"rN9":[],"Widget":[]},"KeT":{"lLS":[],"AOA":["Qc2"],"jU":[],"F9":[],"Y3C":[]},"KrM":{"q8v":[]},"kj0":{"q8v":[]},"ADR":{"q8v":[]},"GzT":{"q8v":[]},"SmartRefresher":{"kX1":[],"Widget":[]},"eDm":{"wm":["SmartRefresher"]},"vYQ":{"SI4":[],"WFg":[],"Widget":[]},"ov":{"ChangeNotifier":[],"rRE":[]}}'))
N.FF0(b.typeUniverse,JSON.parse('{"ol0":1,"y2N":1,"xvw":1,"wbs":1}'))
var y=(function rtii(){var x=N.lRH
return{m:x("Mjk<CP5>"),k:x("BoxConstraints"),h:x("hA"),T:x("jd<qwE<CP5>>"),p:x("jd<Widget>"),O:x("jd<mV4>"),t:x("Tf9<Ds>"),y:x("zgS"),P:x("c8"),B:x("JXt"),r:x("vYQ"),X:x("I6H<Rr>"),D:x("yKX"),b:x("ov<kj0>"),i:x("ov<KrM>"),A:x("Xo8"),K:x("nh"),g:x("aJn<oO8<lLS>>"),W:x("K8i"),S:x("im8"),q:x("eDm"),V:x("qwE<CP5>"),U:x("VuK<CP5>"),L:x("bL<Offset>"),Y:x("bL<CP5>"),a:x("tZu"),l:x("Widget"),_:x("CP5"),z:x("@"),C:x("f5Y?"),s:x("EJ?"),Z:x("~()?"),H:x("~")}})();(function constants(){var x=a.makeConstList
PART8_C.R5=new N.CircularProgressIndicator(2,null,null,null,null,null,null,null)
PART8_C.zi=new N.VD(null,!0,10,1,null)
PART8_C.IconPosition_0=new PART8.Ela(0,"left")
PART8_C.IconPosition_2=new PART8.Ela(2,"top")
PART8_C.IconPosition_3=new PART8.Ela(3,"bottom")
PART8_C.ep=new N.IconData(57504,"MaterialIcons",null,!1)
PART8_C.Ti=new N.Icon(PART8_C.ep,null,C.Rd,null,null,null)
PART8_C.Hh=new N.IconData(57846,"MaterialIcons",null,!1)
PART8_C.QJ=new N.Icon(PART8_C.Hh,null,C.Rd,null,null,null)
PART8_C.yNY=new N.IconData(58644,"MaterialIcons",null,!1)
PART8_C.XF=new N.Icon(PART8_C.yNY,null,C.Rd,null,null,null)
PART8_C.qa=new N.IconData(57495,"MaterialIcons",null,!1)
PART8_C.Mt=new N.Icon(PART8_C.qa,null,C.Rd,null,null,null)
PART8_C.nW=new N.IconData(57537,"MaterialIcons",null,!1)
PART8_C.ZG=new N.Icon(PART8_C.nW,null,C.Rd,null,null,null)
PART8_C.c8=new N.IconData(57911,"MaterialIcons",null,!1)
PART8_C.Il=new N.Icon(PART8_C.c8,null,C.Rd,null,null,null)
PART8_C.fU=new N.ey(0,0.6666666666666666,C.t0)
PART8_C.tB=new N.ey(0.1,0.33,C.t0)
PART8_C.LoadStyle_0=new PART8.GzT(0,"ShowAlways")
PART8_C.LoadStyle_1=new PART8.GzT(1,"HideAlways")
PART8_C.LoadStyle_2=new PART8.GzT(2,"ShowWhenLoading")
PART8_C.D2=N.J(x([PART8_C.LoadStyle_0,PART8_C.LoadStyle_1,PART8_C.LoadStyle_2]),N.lRH("jd<GzT>"))
PART8_C.LoadStatus_0=new PART8.kj0(0,"idle")
PART8_C.LoadStatus_1=new PART8.kj0(1,"canLoading")
PART8_C.LoadStatus_2=new PART8.kj0(2,"loading")
PART8_C.LoadStatus_3=new PART8.kj0(3,"noMore")
PART8_C.LoadStatus_4=new PART8.kj0(4,"failed")
PART8_C.tV=N.J(x([PART8_C.LoadStatus_0,PART8_C.LoadStatus_1,PART8_C.LoadStatus_2,PART8_C.LoadStatus_3,PART8_C.LoadStatus_4]),N.lRH("jd<kj0>"))
PART8_C.RefreshStatus_0=new PART8.KrM(0,"idle")
PART8_C.RefreshStatus_1=new PART8.KrM(1,"canRefresh")
PART8_C.RefreshStatus_2=new PART8.KrM(2,"refreshing")
PART8_C.RefreshStatus_3=new PART8.KrM(3,"completed")
PART8_C.RefreshStatus_4=new PART8.KrM(4,"failed")
PART8_C.RefreshStatus_5=new PART8.KrM(5,"canTwoLevel")
PART8_C.RefreshStatus_6=new PART8.KrM(6,"twoLevelOpening")
PART8_C.RefreshStatus_7=new PART8.KrM(7,"twoLeveling")
PART8_C.RefreshStatus_8=new PART8.KrM(8,"twoLevelClosing")
PART8_C.ZT=N.J(x([PART8_C.RefreshStatus_0,PART8_C.RefreshStatus_1,PART8_C.RefreshStatus_2,PART8_C.RefreshStatus_3,PART8_C.RefreshStatus_4,PART8_C.RefreshStatus_5,PART8_C.RefreshStatus_6,PART8_C.RefreshStatus_7,PART8_C.RefreshStatus_8]),N.lRH("jd<KrM>"))
PART8_C.IconPosition_1=new PART8.Ela(1,"right")
PART8_C.cu=N.J(x([PART8_C.IconPosition_0,PART8_C.IconPosition_1,PART8_C.IconPosition_2,PART8_C.IconPosition_3]),N.lRH("jd<Ela>"))
PART8_C.RefreshStyle_0=new PART8.ADR(0,"Follow")
PART8_C.RefreshStyle_1=new PART8.ADR(1,"UnFollow")
PART8_C.RefreshStyle_2=new PART8.ADR(2,"Behind")
PART8_C.RefreshStyle_3=new PART8.ADR(3,"Front")
PART8_C.Ol=N.J(x([PART8_C.RefreshStyle_0,PART8_C.RefreshStyle_1,PART8_C.RefreshStyle_2,PART8_C.RefreshStyle_3]),N.lRH("jd<ADR>"))
PART8_C.b4=new N.x7o(2.2,150,16)
PART8_C.xG=new N.TextStyle(!0,C.Rd,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null,null)
PART8_C.QV=N.xql("BouncingScrollPhysics")
PART8_C.iZ=N.xql("Ds")
PART8_C.Ii=N.xql("Rr")
PART8_C.il=N.xql("yKX")
PART8_C.N0=N.xql("Zs6")
PART8_C.p7=N.xql("KrM")})()}
$__dart_deferred_initializers__["t8XguSA9xwU+x0jYXSO31V0yeg4="] = $__dart_deferred_initializers__.current

window.init.initializeLoadedHunk("t8XguSA9xwU+x0jYXSO31V0yeg4=");

