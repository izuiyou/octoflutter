self.$__dart_deferred_initializers__=self.$__dart_deferred_initializers__||Object.create(null)
$__dart_deferred_initializers__.current=function(a,b,c,$){var PART9={YE1:function YE1(d,e){this.c=d
this.a=e},Jo6:function Jo6(d,e,f,g,h){var _=this
_.fP$=d
_.po$=e
_.Ob3$=f
_.Ik$=g
_.k4=null
_.d=!1
_.f=_.e=null
_.x=_.r=!1
_.y=null
_.z=!1
_.Q=!0
_.ch=null
_.cx=!1
_.cy=null
_.db=!1
_.dx=h
_.dy=!1
_.fr=$
_.fx=!0
_.fy=null
_.go=!0
_.id=null
_.a=0
_.c=_.b=null},GVJ:function GVJ(){},arY:function arY(){},
Lm(d,e,f){var x,w,v,u,t,s,r,q,p,o,n,m,l,k=J.U6(d),j=k.gA(d)+f.GD(k.gA(d)),i=y.t,h=N.J([],i),g=N.J([],i)
i=y.S
x=N.I(j,0,!1,i)
w=N.I(j,0,!1,i)
v=N.I(j,0,!1,i)
u=N.F(i,i)
t=J.If(e,i)
for(s=0;s<e;++s)t[s]=0
r=new PART9.Hx(t,w,v,e,h,g,x)
r.$3(d,u,0)
q=N.I(u.gA(u),-1,!1,i)
for(i=u.gJ(u),i=i.gw(i);i.l();){p=i.gR(i)
o=u.q(0,p)
o.toString
q[p]=o}n=f.nB(q,e)
m=k.br(d)
if(n.length!==0){i=N.t6(n).CT("lJ<1,QuiltedGridTile>")
l=N.Y1(new N.lJ(n,new PART9.bX(d),i),!0,i.CT("aL.E"))
r.$3(l,null,k.gA(d))
C.Nm.FV(m,l)}k=C.Nm.qx(t,PART9_C.NY)
return new PART9.Il(m,m.length,v,w,x,h,g,k)},
quiltedToPattern(d,e,f){return PART9.Lm(d,e,f)},
QuiltedGridTile:function QuiltedGridTile(d,e){this.a=d
this.b=e},
SliverQuiltedGridDelegate:function SliverQuiltedGridDelegate(d,e,f,g){var _=this
_.a=d
_.c=e
_.d=f
_.e=g},
Il:function Il(d,e,f,g,h,i,j,k){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i
_.r=j
_.x=k},
FUd:function FUd(d,e,f,g,h,i,j){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i
_.r=j},
dGx:function dGx(){},
B36:function B36(){},
u8P:function u8P(){},
jUV:function jUV(){},
Hx:function Hx(d,e,f,g,h,i,j){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i
_.r=j},
bX:function bX(d){this.a=d},
BrN:function BrN(d,e){this.a=d
this.b=e},
KLt:function KLt(){},
H9H:function H9H(d,e,f,g,h,i,j){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h
_.f=i
_.r=j},
AJV:function AJV(){},
StairedGridTile:function StairedGridTile(d,e){this.a=d
this.b=e},
SliverStairedGridDelegate:function SliverStairedGridDelegate(d,e,f,g,h,i,j,k){var _=this
_.r=d
_.x=e
_.a=f
_.b=g
_.c=h
_.d=i
_.e=j
_.f=k},
WovenGridTile:function WovenGridTile(d,e,f){this.a=d
this.b=e
this.c=f},
V8:function V8(d,e,f,g,h,i,j){var _=this
_.r=d
_.a=e
_.b=f
_.c=g
_.d=h
_.e=i
_.f=j},
nwa:function nwa(){},
UWd(d,e,f,g){var x=new PART9.l4t(f,g,e,new PART9.ST(),N.J([],y.t),N.J([],y.n),d,N.F(y.S,y.x),0,null,null,N.amA())
x.gup()
x.gLX()
x.fr=!1
return x},
eN:function eN(d,e,f){var _=this
_.b=_.y=_.x=null
_.c=!1
_.Af$=d
_.G7$=e
_.UH$=f
_.a=null},
l4t:function l4t(d,e,f,g,h,i,j,k,l,m,n,o){var _=this
_.cf=d
_.cd=e
_.pG=f
_.v8=0
_.Xi=g
_.I6=h
_.Jq=i
_.qJ=0
_.r3=null
_.M7=j
_.lq=k
_.Ub=$
_.NH=!0
_.th$=l
_.MA$=m
_.ph$=n
_.k4=null
_.d=!1
_.f=_.e=null
_.x=_.r=!1
_.y=null
_.z=!1
_.Q=!0
_.ch=null
_.cx=!1
_.cy=null
_.db=!1
_.dx=o
_.dy=!1
_.fr=$
_.fx=!0
_.fy=null
_.go=!0
_.id=null
_.a=0
_.c=_.b=null},
ST:function ST(){},
zZg:function zZg(d){this.a=d},
z8a:function z8a(){},
diE:function diE(d,e){this.a=d
this.b=e},
iex:function iex(d,e,f){this.a=d
this.b=e
this.c=f},
rE7:function rE7(){},
cwr:function cwr(d){this.a=d},
wVU:function wVU(d){this.a=d},
ian:function ian(d,e,f,g,h){var _=this
_.a=d
_.b=e
_.c=f
_.d=g
_.e=h},
HeE:function HeE(d){this.a=d},
kQg:function kQg(d,e){this.a=d
this.b=e},
i7a:function i7a(d,e){this.a=d
this.b=e},
SDQ:function SDQ(){},
SliverSimpleGridDelegateWithFixedCrossAxisCount:function SliverSimpleGridDelegateWithFixedCrossAxisCount(d){this.a=d},
SliverSimpleGridDelegateWithMaxCrossAxisExtent:function SliverSimpleGridDelegateWithMaxCrossAxisExtent(d){this.a=d},
AQo(d,e){var x,w,v,u,t,s,r,q=d.length
for(x=PART9_C.LF,w=0;w<q;++w){v=d[w]
u=x.b
if(u<v||Math.abs(u-v)<1e-10)continue
t=0
s=0
r=0
while(!0){if(!(s<e&&r<q&&q-r>=e-s))break
u=d[r]
if(u<v||Math.abs(u-v)<1e-10){++s
if(s===e)x=new PART9.fR3(t,v)}else{t=r+1
s=0}++r}}return x},
nIB(d,e,f){d.UjZ(e)},
z8M(d,e,f){d.yEC(0,e,f)},
AQd:function AQd(d,e,f){var _=this
_.x=_.r=_.f=_.e=null
_.G7$=d
_.UH$=e
_.a=f},
Xe3:function Xe3(){},
StaggeredGridDelegateWithFixedCrossAxisCount:function StaggeredGridDelegateWithFixedCrossAxisCount(d){this.a=d},
StaggeredGridDelegateWithMaxCrossAxisExtent:function StaggeredGridDelegateWithMaxCrossAxisExtent(d){this.a=d},
y3I:function y3I(d,e,f,g,h,i,j,k,l){var _=this
_.LD=d
_.My=e
_.RZ=f
_.ij=g
_.TQ=h
_.ca=!1
_.th$=i
_.MA$=j
_.ph$=k
_.r1=_.k4=null
_.r2=!1
_.ry=_.rx=null
_.x1=0
_.d=!1
_.f=_.e=null
_.x=_.r=!1
_.y=null
_.z=!1
_.Q=!0
_.ch=null
_.cx=!1
_.cy=null
_.db=!1
_.dx=l
_.dy=!1
_.fr=$
_.fx=!0
_.fy=null
_.go=!0
_.id=null
_.a=0
_.c=_.b=null},
QQE:function QQE(){},
fR3:function fR3(d,e){this.a=d
this.b=e},
vUJ:function vUJ(){},
pLz:function pLz(){},
JOv:function JOv(d,e,f){this.G7$=d
this.UH$=e
this.a=f},
OJO:function OJO(d,e,f,g,h,i,j,k,l){var _=this
_.LD=d
_.My=e
_.RZ=f
_.ij=g
_.TQ=h
_.th$=i
_.MA$=j
_.ph$=k
_.r1=_.k4=null
_.r2=!1
_.ry=_.rx=null
_.x1=0
_.d=!1
_.f=_.e=null
_.x=_.r=!1
_.y=null
_.z=!1
_.Q=!0
_.ch=null
_.cx=!1
_.cy=null
_.db=!1
_.dx=l
_.dy=!1
_.fr=$
_.fx=!0
_.fy=null
_.go=!0
_.id=null
_.a=0
_.c=_.b=null},
tYT:function tYT(d){this.a=d},
Wn8:function Wn8(d){this.a=d},
X85:function X85(d,e){this.a=d
this.b=e},
B08:function B08(){},
XbJ:function XbJ(){},
AlignedGridView:function AlignedGridView(d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x,a0,a1,a2){var _=this
_.ej=d
_.lZ=e
_.Ab=f
_.zR=g
_.Ky=h
_.bR=i
_.pV=j
_.fx=k
_.c=l
_.d=m
_.e=n
_.f=o
_.r=p
_.x=q
_.y=r
_.z=s
_.Q=t
_.ch=u
_.cx=v
_.cy=w
_.db=x
_.dx=a0
_.dy=a1
_.a=a2},
MasonryGridView:function MasonryGridView(d,e,f,g,h,i,j,k,l,m,n,o,p,q,r,s,t,u,v,w,x){var _=this
_.ej=d
_.lZ=e
_.Ab=f
_.zR=g
_.fx=h
_.c=i
_.d=j
_.e=k
_.f=l
_.r=m
_.x=n
_.y=o
_.z=p
_.Q=q
_.ch=r
_.cx=s
_.cy=t
_.db=u
_.dx=v
_.dy=w
_.a=x},
Bvq:function Bvq(d,e,f,g,h,i){var _=this
_.c=d
_.d=e
_.e=f
_.f=g
_.r=h
_.a=i},
Llx:function Llx(d,e){this.a=d
this.b=e},
LBT:function LBT(d,e,f){this.a=d
this.b=e
this.c=f},
MzJ:function MzJ(d,e){this.c=d
this.a=e},
qV(d,e,f,g,h){return new PART9.SliverMasonryGrid(f,h,d,e,g)},
SliverMasonryGrid:function SliverMasonryGrid(d,e,f,g,h){var _=this
_.f=d
_.r=e
_.x=f
_.d=g
_.a=h},
StaggeredGrid:function StaggeredGrid(d,e,f,g,h,i){var _=this
_.e=d
_.f=e
_.r=f
_.x=g
_.c=h
_.a=i},
StaggeredGridTile:function StaggeredGridTile(d,e,f,g,h){var _=this
_.f=d
_.r=e
_.x=f
_.b=g
_.a=h},
bkE:function bkE(d,e,f,g,h){var _=this
_.e=d
_.f=e
_.r=f
_.c=g
_.a=h},
xj(d){var x,w,v
for(x=d.length,w=0,v=1;v<x;++v)if(d[v]<d[w])w=v
return w},
EIK(d){var x=J.U6(d),w=x.q(d,""),v=x.q(d,""),u=x.q(d,""),t=x.q(d,""),s=x.q(d,""),r=x.q(d,""),q=x.q(d,""),p=x.q(d,""),o=x.q(d,""),n=x.q(d,""),m=x.q(d,""),l=x.q(d,""),k=x.q(d,"")
return N.J([new PART9.StaggeredGrid(v,u,t,s,r,w),new PART9.StaggeredGrid(new PART9.StaggeredGridDelegateWithFixedCrossAxisCount(p),o,n,m,l,q),new PART9.StaggeredGrid(new PART9.StaggeredGridDelegateWithMaxCrossAxisExtent(x.q(d,"")),x.q(d,""),x.q(d,""),x.q(d,""),x.q(d,""),k)],y.q)},
oz9(d){return new PART9.StaggeredGridDelegateWithMaxCrossAxisExtent(J.x9(d,""))},
Hln(d){return new PART9.StaggeredGridDelegateWithFixedCrossAxisCount(J.x9(d,""))},
oiN(d){var x=null,w=J.U6(d),v=w.q(d,""),u=w.q(d,""),t=w.q(d,""),s=w.q(d,""),r=w.q(d,""),q=w.q(d,""),p=w.q(d,""),o=w.q(d,""),n=w.q(d,"")
return N.J([new PART9.StaggeredGridTile(u,t,x,s,v),new PART9.StaggeredGridTile(q,x,p,o,r),new PART9.StaggeredGridTile(w.q(d,""),x,x,w.q(d,""),n)],y._)},
Pjh(i1){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,b0,b1,b2,b3,b4,b5,b6,b7,b8,b9,c0,c1,c2,c3,c4,c5,c6,c7,c8,c9,d0,d1,d2,d3,d4,d5,d6,d7,d8,d9,e0,e1,e2,e3,e4,e5,e6,e7,e8,e9,f0,f1,f2,f3,f4,f5,f6,f7=null,f8=J.U6(i1),f9=f8.q(i1,""),g0=f8.q(i1,""),g1=f8.q(i1,""),g2=f8.q(i1,""),g3=f8.q(i1,""),g4=f8.q(i1,""),g5=f8.q(i1,""),g6=f8.q(i1,""),g7=f8.q(i1,""),g8=f8.q(i1,""),g9=f8.q(i1,""),h0=f8.q(i1,""),h1=f8.q(i1,""),h2=f8.q(i1,""),h3=f8.q(i1,""),h4=f8.q(i1,""),h5=f8.q(i1,""),h6=f8.q(i1,""),h7=f8.q(i1,""),h8=f8.q(i1,""),h9=f8.q(i1,""),i0=f8.q(i1,"")
if(h6==null)h6=g9
x=g3==null
if(x)w=g2==null&&g0===C.Axis_1
else w=g3
if(g4==null){if(g3!==!0)g3=x&&g2==null&&g0===C.Axis_1
else g3=!0
g3=g3?C.UF:f7}else g3=g4
g4=f8.q(i1,"")
x=f8.q(i1,"")
v=f8.q(i1,"")
u=f8.q(i1,"")
t=f8.q(i1,"")
s=f8.q(i1,"")
r=f8.q(i1,"")
q=f8.q(i1,"")
p=f8.q(i1,"")
o=f8.q(i1,"")
n=f8.q(i1,"")
m=f8.q(i1,"")
l=f8.q(i1,"")
k=f8.q(i1,"")
j=f8.q(i1,"")
i=f8.q(i1,"")
h=f8.q(i1,"")
g=f8.q(i1,"")
f=f8.q(i1,"")
e=f8.q(i1,"")
d=f8.q(i1,"")
a0=f8.q(i1,"")
if(g==null)g=l
a1=t==null
if(a1)a2=u==null&&x===C.Axis_1
else a2=t
if(s==null){if(t!==!0)t=a1&&u==null&&x===C.Axis_1
else t=!0
t=t?C.UF:f7}else t=s
s=f8.q(i1,"")
a1=f8.q(i1,"")
a3=f8.q(i1,"")
a4=f8.q(i1,"")
a5=f8.q(i1,"")
a6=f8.q(i1,"")
a7=f8.q(i1,"")
a8=f8.q(i1,"")
a9=f8.q(i1,"")
b0=f8.q(i1,"")
b1=f8.q(i1,"")
b2=f8.q(i1,"")
b3=f8.q(i1,"")
b4=f8.q(i1,"")
b5=f8.q(i1,"")
b6=f8.q(i1,"")
b7=f8.q(i1,"")
b8=f8.q(i1,"")
b9=a5==null
if(b9)c0=a4==null&&a1===C.Axis_1
else c0=a5
if(a6==null){if(a5!==!0)a5=b9&&a4==null&&a1===C.Axis_1
else a5=!0
a5=a5?C.UF:f7}else a5=a6
a6=f8.q(i1,"")
b9=f8.q(i1,"")
c1=f8.q(i1,"")
c2=f8.q(i1,"")
c3=f8.q(i1,"")
c4=f8.q(i1,"")
c5=f8.q(i1,"")
c6=f8.q(i1,"")
c7=f8.q(i1,"")
c8=f8.q(i1,"")
c9=f8.q(i1,"")
d0=f8.q(i1,"")
d1=f8.q(i1,"")
d2=f8.q(i1,"")
d3=f8.q(i1,"")
d4=f8.q(i1,"")
d5=f8.q(i1,"")
d6=f8.q(i1,"")
d7=f8.q(i1,"")
if(d3==null)d3=d1
d8=c3==null
if(d8)d9=c2==null&&b9===C.Axis_1
else d9=c3
if(c4==null){if(c3!==!0)c3=d8&&c2==null&&b9===C.Axis_1
else c3=!0
c3=c3?C.UF:f7}else c3=c4
c4=f8.q(i1,"")
d8=f8.q(i1,"")
e0=f8.q(i1,"")
e1=f8.q(i1,"")
e2=f8.q(i1,"")
e3=f8.q(i1,"")
e4=f8.q(i1,"")
e5=f8.q(i1,"")
e6=f8.q(i1,"")
e7=f8.q(i1,"")
e8=f8.q(i1,"")
e9=f8.q(i1,"")
f0=f8.q(i1,"")
f1=f8.q(i1,"")
f2=f8.q(i1,"")
f3=f8.q(i1,"")
f4=f8.q(i1,"")
f8=f8.q(i1,"")
f5=N.qF(f0,!0,!0,!0,N.Um(),0)
f0=f1==null?J.Hm(f0):f1
f1=e2==null
if(f1)f6=e1==null&&d8===C.Axis_1
else f6=e2
if(e3==null){if(e2!==!0)e2=f1&&e1==null&&d8===C.Axis_1
else e2=!0
e2=e2?C.UF:f7}else e2=e3
return N.J([new PART9.MasonryGridView(g7,h0,h1,new N.SliverChildBuilderDelegate(g8,g9,h2,h3,h4,0,N.Um(),f7),g6,g0,g1,g2,w,g3,f7,g5,f7,0,h5,h6,h7,h8,h9,i0,f9),new PART9.MasonryGridView(new PART9.SliverSimpleGridDelegateWithFixedCrossAxisCount(p),o,n,new N.SliverChildBuilderDelegate(m,l,k,j,i,0,N.Um(),f7),q,x,v,u,a2,t,f7,r,f7,0,h,g,f,e,d,a0,g4),new PART9.MasonryGridView(a9,b1,b2,b0,a8,a1,a3,a4,c0,a5,f7,a7,f7,0,b3,b4,b5,b6,b7,b8,s),new PART9.MasonryGridView(new PART9.SliverSimpleGridDelegateWithMaxCrossAxisExtent(c7),c8,c9,new N.SliverChildBuilderDelegate(d0,d1,!0,!0,!0,0,N.Um(),f7),c6,b9,c1,c2,d9,c3,f7,c5,f7,0,d2,d3,d4,d5,d6,d7,a6),new PART9.MasonryGridView(e6,e7,e8,f5,e5,d8,e0,e1,f6,e2,f7,e4,f7,0,e9,f0,f2,f3,f4,f8,c4)],y.z)},
JYG(d){return new PART9.SliverSimpleGridDelegateWithFixedCrossAxisCount(J.x9(d,""))},
Go2(d){return new PART9.SliverSimpleGridDelegateWithMaxCrossAxisExtent(J.x9(d,""))},
X8O(d){var x=J.U6(d),w=x.q(d,""),v=x.q(d,""),u=x.q(d,""),t=x.q(d,""),s=x.q(d,""),r=x.q(d,""),q=x.q(d,""),p=x.q(d,""),o=x.q(d,""),n=x.q(d,""),m=x.q(d,""),l=x.q(d,""),k=x.q(d,""),j=x.q(d,""),i=x.q(d,"")
return N.J([new PART9.SliverMasonryGrid(new PART9.SliverSimpleGridDelegateWithFixedCrossAxisCount(v),r,s,new N.SliverChildBuilderDelegate(u,t,!0,!0,!0,0,N.Um(),null),w),new PART9.SliverMasonryGrid(new PART9.SliverSimpleGridDelegateWithMaxCrossAxisExtent(p),l,m,new N.SliverChildBuilderDelegate(o,n,!0,!0,!0,0,N.Um(),null),q),PART9.qV(x.q(d,""),j,i,k,x.q(d,""))],y.H)},
MyP(d){var x=J.U6(d),w=x.q(d,""),v=x.q(d,""),u=x.q(d,"")
return new PART9.SliverQuiltedGridDelegate(w,x.q(d,""),x.q(d,""),PART9.Lm(v,w,u))},
Xpv(d){var x=J.U6(d)
return new PART9.QuiltedGridTile(x.q(d,""),x.q(d,""))},
quiltedGridRepeatPattern(d){switch(d){case 0:return PART9_C.zY
case 1:return PART9_C.jl
case 2:default:return PART9_C.zh}},
sliverWovenGridDelegateCount(d,e,f,g,h){return new PART9.V8(h,f,g,d,J.Hm(d),e,null)},
sliverWovenGridDelegateExtent(d,e,f,g,h){return new PART9.V8(h,f,g,d,J.Hm(d),null,e)},
MDc(d){var x=J.U6(d)
return new PART9.WovenGridTile(x.q(d,""),x.q(d,""),x.q(d,""))},
Nqr(d){var x=J.U6(d)
return new PART9.StairedGridTile(x.q(d,""),x.q(d,""))},
vuP(d){var x=J.U6(d),w=x.q(d,""),v=x.q(d,""),u=x.q(d,"")
return new PART9.SliverStairedGridDelegate(x.q(d,""),x.q(d,""),v,u,w,J.Hm(w),1,null)},
air(e5){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,b0,b1,b2,b3,b4,b5,b6,b7,b8,b9,c0,c1=null,c2=J.U6(e5),c3=c2.q(e5,""),c4=c2.q(e5,""),c5=c2.q(e5,""),c6=c2.q(e5,""),c7=c2.q(e5,""),c8=c2.q(e5,""),c9=c2.q(e5,""),d0=c2.q(e5,""),d1=c2.q(e5,""),d2=c2.q(e5,""),d3=c2.q(e5,""),d4=c2.q(e5,""),d5=c2.q(e5,""),d6=c2.q(e5,""),d7=c2.q(e5,""),d8=c2.q(e5,""),d9=c2.q(e5,""),e0=c2.q(e5,""),e1=c2.q(e5,""),e2=c2.q(e5,""),e3=c2.q(e5,""),e4=c7==null
if(e4)x=c6==null&&c4===C.Axis_1
else x=c7
if(c8==null){if(c7!==!0)c7=e4&&c6==null&&c4===C.Axis_1
else c7=!0
c7=c7?C.UF:c1}else c7=c8
c8=c2.q(e5,"")
e4=c2.q(e5,"")
w=c2.q(e5,"")
v=c2.q(e5,"")
u=c2.q(e5,"")
t=c2.q(e5,"")
s=c2.q(e5,"")
r=c2.q(e5,"")
q=c2.q(e5,"")
p=c2.q(e5,"")
o=c2.q(e5,"")
n=c2.q(e5,"")
m=c2.q(e5,"")
l=c2.q(e5,"")
k=c2.q(e5,"")
j=c2.q(e5,"")
i=c2.q(e5,"")
h=c2.q(e5,"")
g=c2.q(e5,"")
f=c2.q(e5,"")
e=c2.q(e5,"")
if(i==null)i=m
d=u==null
if(d)a0=v==null&&e4===C.Axis_1
else a0=u
if(t==null){if(u!==!0)u=d&&v==null&&e4===C.Axis_1
else u=!0
u=u?C.UF:c1}else u=t
t=c2.q(e5,"")
d=c2.q(e5,"")
a1=c2.q(e5,"")
a2=c2.q(e5,"")
a3=c2.q(e5,"")
a4=c2.q(e5,"")
a5=c2.q(e5,"")
a6=c2.q(e5,"")
a7=c2.q(e5,"")
a8=c2.q(e5,"")
a9=c2.q(e5,"")
b0=c2.q(e5,"")
b1=c2.q(e5,"")
b2=c2.q(e5,"")
b3=c2.q(e5,"")
b4=c2.q(e5,"")
b5=c2.q(e5,"")
b6=c2.q(e5,"")
b7=c2.q(e5,"")
b8=c2.q(e5,"")
c2=c2.q(e5,"")
if(b5==null)b5=b1
b9=a3==null
if(b9)c0=a2==null&&d===C.Axis_1
else c0=a3
if(a4==null){if(a3!==!0)a3=b9&&a2==null&&d===C.Axis_1
else a3=!0
a3=a3?C.UF:c1}else a3=a4
return N.J([new PART9.AlignedGridView(d1,d6,d7,d2,d3,d4,d5,d0,c4,c5,c6,x,c7,c1,c9,c1,0,d8,d9,e0,e1,e2,e3,c3),new PART9.AlignedGridView(new PART9.SliverSimpleGridDelegateWithFixedCrossAxisCount(q),p,o,n,m,l,k,r,e4,w,v,a0,u,c1,s,c1,0,j,i,h,g,f,e,c8),new PART9.AlignedGridView(new PART9.SliverSimpleGridDelegateWithMaxCrossAxisExtent(a7),a8,a9,b0,b1,b2,b3,a6,d,a1,a2,c0,a3,c1,a5,c1,0,b4,b5,b6,b7,b8,c2,t)],y.E)},
GL(d){var x,w=d.a
w.t(0,"StaggeredGrid",PART9.B1())
w.t(0,"StaggeredGridDelegateWithMaxCrossAxisExtent",PART9.dt())
w.t(0,"StaggeredGridDelegateWithFixedCrossAxisCount",PART9.SG())
w.t(0,"StaggeredGridTile",PART9.Ik())
w.t(0,"MasonryGridView",PART9.hm())
w.t(0,"SliverSimpleGridDelegateWithMaxCrossAxisExtent",PART9.Oh())
w.t(0,"SliverSimpleGridDelegateWithFixedCrossAxisCount",PART9.y6())
w.t(0,"SliverMasonryGrid",PART9.vm())
w.t(0,"SliverQuiltedGridDelegate",PART9.AS())
w.t(0,"QuiltedGridTile",PART9.pH())
x=d.d
x.t(0,"quiltedGridRepeatPattern",PART9.C0())
x.t(0,"quiltedToPattern",PART9.wx())
x.t(0,"sliverWovenGridDelegateCount",PART9.QU())
x.t(0,"sliverWovenGridDelegateExtent",PART9.ZG())
w.t(0,"WovenGridTile",PART9.av())
w.t(0,"StairedGridTile",PART9.Tw())
w.t(0,"SliverStairedGridDelegate",PART9.DY())
w.t(0,"AlignedGridView",PART9.Av())}},N,C,J,PART9_C
a.setFunctionNamesIfNecessary([PART9])
PART9=a.updateHolder(c[8],PART9)
window.PART9=PART9
N=c[0]
C=c[2]
J=c[1]
PART9_C=c[16]
window.PART9_C=PART9_C
PART9.YE1.prototype={
gGq(){return this.c},
Xb(d){var x=new PART9.Jo6(null,!0,null,null,N.amA())
x.gup()
x.gLX()
x.fr=!1
return x}}
PART9.Jo6.prototype={
K1t(){var x,w=this
w.nIs()
x=w.Ik$
if(x!=null)x.yEC(0,y.p.a(N.jU.prototype.gHv.call(w)),!0)
x=w.Ik$
x=x==null?null:x.k4
w.k4=x==null?C.LA:x},
kl(d,e){},
It(d,e){var x,w=this.Ik$
if(w==null)x=null
else{x=w.k4
x=x==null?null:x.x}if(x===!0){w.toString
d.u3i(w,e)}},
z0(d,e,f){var x=this.Ik$
return x!=null&&x.k4.r>0&&x.w5(d,e,f)}}
PART9.GVJ.prototype={
UE(d){var x
this.Zb(d)
x=this.Ik$
if(x!=null)x.UE(d)},
Ie(d){var x
this.M1(0)
x=this.Ik$
if(x!=null)x.Ie(0)}}
PART9.arY.prototype={}
PART9.QuiltedGridTile.prototype={
Z(d){return"QuiltedGridTile("+this.a+", "+this.b+")"}}
PART9.SliverQuiltedGridDelegate.prototype={
RJ8(d){var x=this,w=d.x,v=x.d,u=(w+v)/x.a-v,t=x.c
return new PART9.FUd(w,t,v,u+t,u+v,x.e,N.a1(d.y))},
oNP(d){return d.a!==this.a||d.c!==this.c||d.d!==this.d}}
PART9.Il.prototype={}
PART9.FUd.prototype={
Aou(d){var x,w,v,u,t
if(d===0)return 0
x=this.f
w=x.b
v=C.jn.xG(d,w)
u=C.jn.zY(d,w)
t=u===0?0:x.e[C.jn.zY(u-1,w)]
return(v*x.x+t)*this.d-this.b},
m4j(d){var x,w,v,u,t,s=this,r=s.f,q=r.b,p=C.jn.xG(d,q)
q=C.jn.zY(d,q)
x=r.d[q]
w=r.c[q]
q=r.a[q]
v=s.e
u=q.b*v-s.c
t=s.d
return new N.DIh((p*r.x+x)*t,s.bBl(w*v,u),q.a*t-s.b,u)},
bBl(d,e){if(this.r)return this.a-d-e
return d},
Ebp(d){var x=C.CD.xG(d,this.d),w=this.f,v=w.x
return C.jn.xG(x,v)*w.b+w.f[C.jn.zY(x,v)]},
crb(d){var x=C.CD.xG(d,this.d),w=this.f,v=w.x
return C.jn.xG(x,v)*w.b+w.r[C.jn.zY(x,v)]}}
PART9.dGx.prototype={}
PART9.B36.prototype={
nB(d,e){return N.J([],y.t)},
GD(d){return 0}}
PART9.u8P.prototype={
nB(d,e){var x,w,v=N.J([],y.t),u=N.A(y.S)
for(x=d.length-1;x>=0;--x){w=d[x]
if(w!==-1&&!u.tg(0,w)){v.push(w)
u.AN(0,w)}}return v},
GD(d){return d}}
PART9.jUV.prototype={
nB(d,e){var x,w,v,u,t=N.J([],y.t),s=N.A(y.S)
for(x=C.jn.xG(d.length,e)-1;x>=0;--x)for(w=x*e,v=0;v<e;++v){u=d[w+v]
if(u!==-1&&!s.tg(0,u)){t.push(u)
s.AN(0,u)}}return t},
GD(d){return d}}
PART9.BrN.prototype={}
PART9.KLt.prototype={
RJ8(d){var x,w,v,u,t,s,r=this,q=r.e
if(q==null){x=r.f
x.toString
q=C.CD.a3(d.x/(x+r.b))}w=r.hKI(d,q)
x=r.a
v=N.a1(d.y)
u=w.a
t=w.b
s=C.Nm.grZ(t)
return new PART9.H9H(x,d.x,v,u,t,u.length,s.a+s.c+x)},
oNP(d){return!J.RM(d.c,this.c)||d.a!==this.a||d.b!==this.b}}
PART9.H9H.prototype={
Aou(d){var x,w,v,u=this
if(d===0)return 0
x=u.f
w=C.jn.xG(d,x)*u.r
if(C.jn.zY(d,x)===0)return w-u.a
v=u.d
v=N.qC(v,0,N.cb(C.jn.zY(d-1,x)+1,"count",y.S),N.t6(v).c)
return w+new N.lJ(v,new PART9.AJV(),v.$ti.CT("lJ<aL.E,CP5>")).qx(0,C.Yy)},
m4j(d){var x,w,v=this,u=v.f,t=C.jn.xG(d,u),s=v.d[C.jn.zY(d,u)]
t=s.a+t*v.r
u=s.b
x=s.c
w=s.d
if(v.c)return new N.DIh(t,v.b-u-w,x,w)
return new N.DIh(t,u,x,w)},
Ebp(d){var x,w,v,u,t,s=this,r=s.r,q=C.CD.xG(d,r),p=d-q*r
for(r=s.f,x=s.e,w=p-s.a,v=0;v<r;++v){u=x[v]
t=u.a
if(t<=p&&t+u.c>=w)return v+q*r}return 0},
crb(d){var x,w,v,u,t,s=this,r=s.r,q=C.CD.xG(d,r),p=d-q*r
for(r=s.f,x=r-1,w=s.e,v=p-s.a;x>=0;--x){u=w[x]
t=u.a
if(t<=p&&t+u.c>=v)return x+q*r}return 0}}
PART9.StairedGridTile.prototype={
Z(d){return"StairedGridTile("+N.Ej(this.a)+", "+N.Ej(this.b)+")"}}
PART9.SliverStairedGridDelegate.prototype={
hKI(b1,b2){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,a0,a1,a2,a3,a4=this,a5=b1.x,a6=a4.c,a7=J.U6(a6),a8=N.I(a7.gA(a6),PART9_C.kg,!1,y.d),a9=a4.x,b0=a9?a5:0
for(x=a4.d,w=a4.b,v=a4.a,u=a4.r,t=a5-w,s=b1.a,r=0,q=0;r<x;r=p){p=r
o=0
while(!0){if(!(o<1&&p<x))break
o+=a7.q(a6,p).a;++p}if(o>1)--p
n=p-r
m=u*n
l=N.j27(s)===C.Axis_0
k=r===0?a5:t
j=p===x?w:0
i=l?m:0
h=C.CD.IV(k-(n-1)*w-j-i,0,a5)
for(g=r,f=0;g<p;++g,b0=a2,q=a3){e=a7.q(a6,g)
n=e.a
k=l?u:0
d=h*n+k
k=e.b
n=l?0:u
a0=d/k+n
if(a9)b0-=d
a1=q+a0
a2=a9?b0-w:b0+d+w
a3=q+v
a8[g]=new N.DIh(q,b0,a0,d)
if(a1>f)f=a1}q=f+v
a9=!a9
b0=a9?t:w}return new PART9.BrN(a8,a8)},
oNP(d){return this.Jj8(d)||d.r!==this.r||d.x!==this.x}}
PART9.WovenGridTile.prototype={
Z(d){var x="WovenGridTile("+N.Ej(this.a),w=this.b
x+=w>1?", "+N.Ej(w):""
w=this.c
return x+(!w.DN(0,PART9_C.QC)?", "+w.Z(0):"")+")"}}
PART9.V8.prototype={
hKI(a8,a9){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,a0,a1,a2,a3,a4,a5=this,a6=N.j27(a8.a)===C.Axis_0,a7=a8.x
if(a6)a7-=a9*a5.r
x=a5.b
w=(a7+x)/a9-x
v=w+x
x=a5.c
u=J.U6(x)
t=u.gA(x)
s=u.Ri(x,new PART9.nwa(),y.i).qx(0,C.Yy)
r=a6?0:a5.r
q=w*s+r
p=a9*2
r=y.d
o=N.I(p,PART9_C.kg,!1,r)
n=N.I(p,PART9_C.kg,!1,r)
for(r=0+w,m=0+q,l=a5.r,k=p-1,j=q+a5.a,i=0;i<p;++i){h=i<a9
g=h?0:j
f=u.q(x,h?C.jn.zY(i,t):C.jn.zY(k-C.jn.zY(i,a9),t))
e=f.b
d=a6?l:0
a0=w*e+d
d=f.a
e=a6?0:l
a1=a0/d+e
a2=h?C.TextDirection_1:C.TextDirection_0
a3=f.c.ZI(a2).W6(new N.Size(a0,a1),new N.Rect(0,0,r,m))
a4=C.jn.zY(i,a9)*v
o[i]=new N.DIh(g+a3.b,a4+a3.a,a1,a0)
n[i]=new N.DIh(g,a4,q,w)}return new PART9.BrN(o,n)},
oNP(d){return this.Jj8(d)||d.r!==this.r||d.e!=this.e}}
PART9.eN.prototype={
Z(d){return"crossAxisIndex="+N.Ej(this.x)+"; "+this.lc(0)}}
PART9.l4t.prototype={
sCp2(d){var x=this
if(x.cf===d)return
if(N.PR(d)!==N.PR(x.cf)||d.oNP(x.cf))x.Ae()
x.cf=d},
slFH(d){if(this.cd===d)return
this.cd=d
this.Ae()},
sqPC(d){if(this.pG===d)return
this.pG=d
this.Ae()},
hE(d){if(!(d.e instanceof PART9.eN))d.e=new PART9.eN(!1,null,null)},
lh(d){var x=y.m.a(d.e).x
x.toString
return this.Xi.$1(x)*this.v8},
ozD(){var x,w=this.HaR(0,0)
if(w){x=y.m.a(this.MA$.e)
x.x=x.a=0}return w},
U7j(d,e){var x,w,v,u,t,s,r,q=this,p=q.MA$
p.toString
x=N.Lh(q).CT("pvS.1")
w=y.m
v=q.I6
u=q.Jq
t=p
s=d
while(!0){if(!(s>0&&t!=null))break
r=w.a(t.e).x
if(r!=null){v.push(r)
u.push(q.UzX(t))}p=t.e
p.toString
t=x.a(p).UH$;--s}q.NpP(d,e)},
cXO(d,e){var x,w,v=this.Qd7(d,!0)
if(v!=null){x=y.m.a(v.e)
w=this.I6
x.x=w.length!==0?w.pop():0
w=this.Jq
x.y=w.length!==0?w.pop():0}return v},
K1t(){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e,d,a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,b0,b1,b2,b3,b4=this,b5=null,b6={},b7=b4.M7
b7.Ky=!1
x=y.p
w=b4.cf.rGP(x.a(N.jU.prototype.gHv.call(b4)),b4.pG)
b4.Xi=N.a1(x.a(N.jU.prototype.gHv.call(b4)).y)?new PART9.zZg(w):new PART9.z8a()
v=x.a(N.jU.prototype.gHv.call(b4))
u=b4.pG
v=(v.x+u)/w
b4.v8=v
t=x.a(N.jU.prototype.gHv.call(b4)).YDu(v-u)
s=x.a(N.jU.prototype.gHv.call(b4)).d+x.a(N.jU.prototype.gHv.call(b4)).Q
r=s+x.a(N.jU.prototype.gHv.call(b4)).ch
q=N.I(w,0,!1,y.i)
p=new PART9.diE(b4,q)
v=b4.r3
if(v!=null&&v!==w){C.Nm.sA(b4.I6,0)
C.Nm.sA(b4.Jq,0)
v=b4.MA$
if(v!=null){v=v.e
v.toString
u=y.D
v=u.a(v).b
v.toString
if(v!==0){o=b4.ph$
o.toString
o=o.e
o.toString
o=u.a(o).b
o.toString
b4.U7j(0,o-v+1)
C.Nm.du(q,0,w,0)
b4.ozD()
n=b4.MA$
n.yEC(0,t,!0)
v=b4.MA$
v.toString
v=v.e
v.toString
v=u.a(v).b
v.toString
m=v
l=0
while(!0){if(!(n!=null&&m<=b4.qJ))break
p.$1(n)
v=n.e
v.toString
v=u.a(v).a
v.toString
n=b4.h7K(t,n,!0);++m
l=v}k=l-s
if(k!==0){b4.k4=N.By2(b5,!1,b5,b5,0,0,0,0,0,k,b5)
return}}}}b4.r3=w
if(b4.MA$==null)if(!b4.ozD()){b4.k4=C.LA
b7.y2z()
return}b6.a=null
j=b4.MA$
v=j.e
v.toString
u=y.D
if(u.a(v).a==null){v=N.Lh(b4).CT("pvS.1")
i=0
while(!0){if(j!=null){o=j.e
o.toString
o=u.a(o).a==null}else o=!1
if(!o)break
o=j.e
o.toString
j=v.a(o).UH$;++i}b4.U7j(i,0)
if(b4.MA$==null)if(!b4.ozD()){b4.k4=C.LA
b7.y2z()
return}}C.Nm.du(q,0,w,1/0)
h=new PART9.iex(b4,q,w)
n=b6.b=b4.MA$
if(n!=null){v=n.e
v.toString
v=u.a(v).b
v.toString
v=v===0}else v=!1
if(v)y.m.a(n.e).x=0
v=N.Lh(b4).CT("pvS.1")
o=y.m
g=n
while(!0){if(!(g!=null&&C.Nm.Vr(q,new PART9.rE7())))break
f=o.a(b6.b.e)
m=f.x
if(m!=null){g=f.a
g.toString
if(J.RM(q[m],1/0))q[m]=g}g=b6.b.e
g.toString
n=v.a(g).UH$
b6.b=n
g=n}j=b4.MA$
for(e=b5;C.Nm.Vr(q,new PART9.cwr(s));e=j){j=b4.cXO(t,!0)
if(j==null){g=b4.MA$
o.a(g.e).a=0
if(s===0){g.yEC(0,t,!0)
j=b4.MA$
if(b6.a==null)b6.a=j
e=j
break}else{b4.k4=N.By2(b5,!1,b5,b5,0,0,0,0,0,-s,b5)
return}}d=C.Nm.qx(q,PART9_C.Ry)
if(d<-1e-10){b4.k4=N.By2(b5,!1,b5,b5,0,0,0,0,0,-d,b5)
f=o.a(b4.MA$.e)
a0=h.$0()
f.a=a0.a
f.x=a0.x
f.a=0
return}a1=h.$0()
f=o.a(j.e)
f.a=a1.a
f.x=a1.x
g=a1.x
g.toString
a2=a1.a
a2.toString
q[g]=a2
if(b6.a==null)b6.a=j}if(s<1e-10)while(!0){g=b4.MA$
g.toString
g=g.e
g.toString
u.a(g)
a2=g.b
a2.toString
if(!(a2>0))break
o.a(g)
j=b4.cXO(t,!0)
a1=h.$0()
g.a=a1.a
g.x=a1.x
g=a1.a
g.toString
if(g<-1e-10){b4.k4=N.By2(b5,!1,b5,b5,0,0,0,0,0,-g,b5)
return}}if(e==null){j.yEC(0,t,!0)
b6.a=j}a3=C.Nm.qx(q,PART9_C.Ry)
b6.c=!0
b6.b=j
g=j.e
g.toString
u.a(g)
a2=g.b
a2.toString
b6.d=a2
o.a(g)
o=g.x
o.toString
g=g.a
g.toString
q[o]=g+b4.UzX(j)+b4.cd
for(a4=0;a4<w;++a4)if(J.RM(q[a4],1/0))q[a4]=0
b6.e=C.Nm.Vr(q,new PART9.wVU(b4))
o=b4.MA$
o.toString
o=o.e
o.toString
o=u.a(o).b
o.toString
b4.qJ=o
a5=new PART9.ian(b6,b4,t,p,q)
for(a6=0;C.Nm.rbG(q,new PART9.kQg(b4,s));){++a6
if(!a5.$0()){b4.U7j(a6-1,0)
a7=C.Nm.qx(q,C.Yy)-b4.cd
b4.k4=N.By2(b5,!1,b5,b5,a7,0,0,0,a7,b5,b5)
return}}while(!0){if(!C.Nm.Vr(q,new PART9.i7a(b4,r))){a8=!1
break}if(!a5.$0()){a8=!0
break}}o=b6.b
if(o!=null){o=o.e
o.toString
o=b6.b=v.a(o).UH$
for(a9=0;o!=null;o=n){++a9
o=o.e
o.toString
n=v.a(o).UH$
b6.b=n}}else a9=0
b4.U7j(a6,a9)
b0=C.Nm.qx(q,C.Yy)-b4.cd
if(a8)b1=b0
else{v=x.a(N.jU.prototype.gHv.call(b4))
o=b4.MA$
o.toString
o=o.e
o.toString
o=u.a(o).b
o.toString
g=b4.ph$
g.toString
g=g.e
g.toString
g=u.a(g).b
g.toString
b1=b7.UGU(v,o,g,a3,b0)}b2=b4.OL(x.a(N.jU.prototype.gHv.call(b4)),a3,b0)
b3=b4.LrP(x.a(N.jU.prototype.gHv.call(b4)),a3,b0)
b4.k4=N.By2(b3,b0>x.a(N.jU.prototype.gHv.call(b4)).d+x.a(N.jU.prototype.gHv.call(b4)).r||x.a(N.jU.prototype.gHv.call(b4)).d>0,b5,b5,b1,0,b2,0,b1,b5,b5)
if(b1===b0)b7.Ky=!0
b7.y2z()}}
PART9.SDQ.prototype={}
PART9.SliverSimpleGridDelegateWithFixedCrossAxisCount.prototype={
rGP(d,e){return this.a},
oNP(d){return d.a!==this.a}}
PART9.SliverSimpleGridDelegateWithMaxCrossAxisExtent.prototype={
rGP(d,e){return C.CD.a3(d.x/(this.a+e))},
oNP(d){return d.a!==this.a}}
PART9.AQd.prototype={
Z(d){return"crossAxisCellCount="+N.Ej(this.e)+"; mainAxisCellCount="+N.Ej(this.f)+"; mainAxisExtent="+N.Ej(this.r)}}
PART9.Xe3.prototype={}
PART9.StaggeredGridDelegateWithFixedCrossAxisCount.prototype={
rGP(d,e){return this.a},
oNP(d){return d.a!==this.a}}
PART9.StaggeredGridDelegateWithMaxCrossAxisExtent.prototype={
rGP(d,e){return C.CD.a3(d/(this.a+e))},
oNP(d){return d.a!==this.a}}
PART9.y3I.prototype={
shI(d){var x=this
if(x.LD===d)return
if(N.PR(d)!==N.PR(x.LD)||d.oNP(x.LD))x.Ae()
x.LD=d},
slFH(d){if(this.My===d)return
this.My=d
this.Ae()},
sqPC(d){if(this.RZ===d)return
this.RZ=d
this.Ae()},
sWl(d){if(this.ij===d)return
this.ij=d
this.Ae()},
sP5(d,e){if(this.TQ===e)return
this.TQ=e
this.Ae()},
hE(d){if(!(d.e instanceof PART9.AQd))d.e=new PART9.AQd(null,null,C.wO)},
n4G(d){return 0},
Emj(d){return 0},
MZD(d){return 0},
Gse(d){return 0},
lWX(d){return this.kBR(d)},
WYH(d){return d.ND(this.WzK(d,PART9.Krp()))},
WzK(a3,a4){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g=this,f=N.j27(g.ij)===C.Axis_1?a3.b:a3.d,e=g.LD.rGP(f,g.RZ),d=(f+g.RZ)/e,a0=new PART9.QQE(),a1=N.I(e,0,!1,y.i),a2=g.MA$
for(x=N.Lh(g).CT("pvS.1"),w=y.C;a2!=null;){v=w.a(a2.e)
u=a0.$2(v,e)
t=d*u-g.RZ
s=v.r
r=s==null
if(r&&v.f==null){a4.$3$parentUsesSize(a2,N.j27(g.ij)===C.Axis_1?N.kzB(null,t):N.kzB(t,null),!0)
r=a2.rx
r.toString
s=N.j27(g.ij)===C.Axis_1?r.b:r.a}else{q=v.f
if(q==null)q=1
if(r)s=d*q-g.My
v.x=s
p=N.j27(g.ij)===C.Axis_1?new N.Size(t,s):new N.Size(s,t)
r=p.a
o=p.b
a4.$2(a2,new N.BoxConstraints(r,r,o,o))}n=PART9.AQo(a1,u)
m=n.b
r=n.a
l=r*d
v.a=N.j27(g.ij)===C.Axis_1?new N.Offset(l,m):new N.Offset(m,l)
k=m+s+g.My
for(j=0;j<u;++j)a1[r+j]=k
r=a2.e
r.toString
a2=x.a(r).UH$}s=C.Nm.qx(a1,C.Yy)-g.My
r=g.ij
if(N.a1(r)){a2=g.MA$
for(;a2!=null;){v=w.a(a2.e)
i=v.a
l=N.j27(r)===C.Axis_1?i.a:i.b
o=N.j27(r)===C.Axis_1?i.b:i.a
h=v.x
h.toString
m=s-o-h
v.a=N.j27(r)===C.Axis_1?new N.Offset(l,m):new N.Offset(m,l)
a2=x.a(v).UH$}}if(N.j27(r)===C.Axis_1&&g.TQ===C.TextDirection_0){a2=g.MA$
for(;a2!=null;){v=w.a(a2.e)
u=a0.$2(v,e)
r=g.RZ
i=v.a
v.a=new N.Offset(f-i.a-(d*u-r),i.b)
r=a2.e
r.toString
a2=x.a(r).UH$}}return N.j27(g.ij)===C.Axis_1?new N.Size(f,s):new N.Size(s,f)},
K1t(){var x=this,w=y.k,v=x.WzK(w.a(N.jU.prototype.gHv.call(x)),PART9.UQW())
w=w.a(N.jU.prototype.gHv.call(x)).ND(v)
x.rx=w
x.ca=!w.DN(0,v)},
vT(d,e){return this.ys(d,e)},
It(d,e){var x,w,v=this
if(v.ca){x=N.mk(v.fr,"_needsCompositing")
w=v.rx
d.WZh(x,e,new N.Rect(0,0,0+w.a,0+w.b),v.gX7w())}else v.uCQ(d,e)}}
PART9.fR3.prototype={}
PART9.vUJ.prototype={
UE(d){var x,w,v
this.Zb(d)
x=this.MA$
for(w=y.C;x!=null;){x.UE(d)
v=x.e
v.toString
x=w.a(v).UH$}},
Ie(d){var x,w,v
this.M1(0)
x=this.MA$
for(w=y.C;x!=null;){x.Ie(0)
v=x.e
v.toString
x=w.a(v).UH$}}}
PART9.pLz.prototype={}
PART9.JOv.prototype={}
PART9.OJO.prototype={
sa9C(d,e){if(this.LD===e)return
this.LD=e
this.Ae()},
sCTh(d,e){var x=this
if(x.My===e)return
x.My=e
x.RZ=N.j27(e)===C.Axis_0
x.ij=N.a1(e)
x.Ae()},
sEa6(d){if(this.TQ===d)return
this.TQ=d
this.Ae()},
hE(d){if(!(d.e instanceof PART9.JOv))d.e=new PART9.JOv(null,null,C.wO)},
vT(d,e){return this.ys(d,e)},
WYH(d){return this.ZV6(d,N.JuV())},
ZV6(d,e){var x,w=this,v=w.RZ,u=v?d.b:d.d,t=w.LD,s=(u+t)/w.TQ-t,r=v?N.kzB(null,s):N.kzB(s,null),q=w.MA$,p=new PART9.tYT(w)
for(v=N.Lh(w).CT("pvS.1"),x=0;q!=null;){x=Math.max(x,N.E0(p.$1(e.$2(q,r))))
t=q.e
t.toString
q=v.a(t).UH$}return w.rx=d.ND(w.RZ?new N.Size(u,x):new N.Size(x,u))},
K1t(){var x,w,v,u,t,s,r,q,p,o,n,m,l=this,k=y.k
l.rx=l.ZV6(k.a(N.jU.prototype.gHv.call(l)),N.EOI())
x=l.RZ?k.a(N.jU.prototype.gHv.call(l)).b:k.a(N.jU.prototype.gHv.call(l)).d
k=l.LD
w=(x+k)/l.TQ-k
v=l.RZ
u=l.rx
t=v?u.b:u.a
s=new PART9.Wn8(l)
r=v?N.kzB(t,w):N.kzB(w,t)
q=l.MA$
p=new PART9.X85(l,w+k)
for(k=y.r,o=0;q!=null;){if(!J.RM(s.$1(q),t))q.yEC(0,r,!0)
n=k.a(q.e)
m=p.$1(o)
n.a=l.RZ?new N.Offset(m,0):new N.Offset(0,m);++o
q=n.UH$}},
It(d,e){this.uCQ(d,e)}}
PART9.B08.prototype={
UE(d){var x,w,v
this.Zb(d)
x=this.MA$
for(w=y.r;x!=null;){x.UE(d)
v=x.e
v.toString
x=w.a(v).UH$}},
Ie(d){var x,w,v
this.M1(0)
x=this.MA$
for(w=y.r;x!=null;){x.Ie(0)
v=x.e
v.toString
x=w.a(v).UH$}}}
PART9.XbJ.prototype={}
PART9.AlignedGridView.prototype={
tTt(d){var x=this
return new PART9.Bvq(x.lZ,x.Ab,x.ej,x.zR,x.Ky,null)}}
PART9.MasonryGridView.prototype={
tTt(d){var x=this
return PART9.qV(x.Ab,x.zR,x.ej,null,x.lZ)}}
PART9.Bvq.prototype={
wgb(d,e){return new PART9.YE1(new PART9.Llx(this,this.r),null)},
bFs(d,e,f){var x
if(e>=0)x=f!=null&&e>=f
else x=!0
if(x)return null
return this.f.$2(d,e)}}
PART9.MzJ.prototype={
wgb(d,e){var x=null,w=this.c
return N.j27(N.G0I(e).a.c)===C.Axis_1?new N.SizedBox(x,w,x,x):new N.SizedBox(w,x,x,x)}}
PART9.SliverMasonryGrid.prototype={
Xb(d){return PART9.UWd(y.F.a(d),this.x,this.f,this.r)},
ls(d,e){e.sCp2(this.f)
e.slFH(this.r)
e.sqPC(this.x)}}
PART9.StaggeredGrid.prototype={
Xb(d){var x,w=this,v=null,u=w.x
if(u==null){u=N.G0I(d)
u=u==null?v:u.a.c}if(u==null)u=C.AxisDirection_2
x=d.f5(y.I)
x.toString
x=new PART9.y3I(w.e,w.f,w.r,u,x.f,0,v,v,N.amA())
x.gup()
x.gLX()
x.fr=!1
x.FV(0,v)
return x},
ls(d,e){var x,w=this
e.shI(w.e)
e.slFH(w.f)
e.sqPC(w.r)
x=w.x
if(x==null){x=N.G0I(d)
x=x==null?null:x.a.c}e.sWl(x==null?C.AxisDirection_2:x)
x=d.f5(y.I)
x.toString
e.sP5(0,x.f)}}
PART9.StaggeredGridTile.prototype={
Jp(d){var x,w,v,u=d.e
if(u instanceof PART9.AQd){x=this.f
if(u.e!==x){u.e=x
w=!0}else w=!1
x=this.r
if(u.f!=x){u.f=x
w=!0}x=this.x
if(u.r!=x){u.r=x
w=!0}if(w){v=d.geT(d)
if(v instanceof PART9.y3I)v.Ae()}}}}
PART9.bkE.prototype={
Xb(d){var x=this.r
x=new PART9.OJO(this.e,x,N.j27(x)===C.Axis_0,N.a1(x),this.f,0,null,null,N.amA())
x.gup()
x.gLX()
x.fr=!1
x.FV(0,null)
return x},
ls(d,e){e.sCTh(0,this.r)
e.sEa6(this.f)
e.sa9C(0,this.e)}}
var z=a.updateTypes(["@(T8C<@,@>)","CP5(CP5)","~(Qc2,BoxConstraints{parentUsesSize:a2j})","~(zM<QuiltedGridTile>,T8C<Ij,Ij>?,Ij)","QuiltedGridTile(Ij)","CP5(WovenGridTile)","eN()","Ij(AQd,Ij)","@(zM<QuiltedGridTile>,Ij,dGx)","StaggeredGridDelegateWithMaxCrossAxisExtent(T8C<@,@>)","StaggeredGridDelegateWithFixedCrossAxisCount(T8C<@,@>)","SliverSimpleGridDelegateWithFixedCrossAxisCount(T8C<@,@>)","SliverSimpleGridDelegateWithMaxCrossAxisExtent(T8C<@,@>)","SliverQuiltedGridDelegate(T8C<@,@>)","QuiltedGridTile(T8C<@,@>)","dGx(Ij)","@(zM<WovenGridTile>,Ij,CP5,CP5,CP5)","@(zM<WovenGridTile>,CP5,CP5,CP5,CP5)","WovenGridTile(T8C<@,@>)","StairedGridTile(T8C<@,@>)","SliverStairedGridDelegate(T8C<@,@>)"])
PART9.Hx.prototype={
$3(d,a0,a1){var x,w,v,u,t,s,r,q,p,o,n,m,l,k,j,i,h,g,f,e=this
for(x=J.U6(d),w=e.r,v=e.a,u=e.f,t=e.e,s=e.d,r=e.b,q=e.c,p=0;p<x.gA(d);++p){o=x.q(d,p)
n=a1+p
m=PART9.xj(v)
l=v[m]
r[n]=l
q[n]=m
k=o.b
j=o.a
for(i=0;i<k;++i){h=m+i
v[h]=v[h]+j
if(a0!=null)for(g=0;g<j;++g)a0.t(0,h+(l+g)*s,p)}for(i=0;i<j;++i){f=l+i
if(t.length===f)t.push(n)
else t[f]=Math.min(t[f],n)
if(u.length===f)u.push(n)
else u[f]=Math.max(u[f],n)}w[n]=C.Nm.qx(v,PART9_C.NY)}},
$S:z+3}
PART9.bX.prototype={
$1(d){return J.x9(this.a,d)},
$S:z+4}
PART9.AJV.prototype={
$1(d){return d.a+d.c},
$S:627}
PART9.nwa.prototype={
$1(d){return d.b/d.a},
$S:z+5}
PART9.ST.prototype={
$1(d){return d},
$S:37}
PART9.zZg.prototype={
$1(d){return this.a-d-1},
$S:37}
PART9.z8a.prototype={
$1(d){return d},
$S:37}
PART9.diE.prototype={
$1(d){var x,w=this.b,v=PART9.xj(w),u=y.m.a(d.e),t=w[v]
u.a=t
u.x=v
t.toString
x=this.a
x=t+x.UzX(d)+x.cd
w[v]=x
return x},
$S:14}
PART9.iex.prototype={
$0(){var x,w,v,u,t,s=this.a,r=y.m.a(s.MA$.e),q=r.y
q.toString
s=s.cd
x=r.x
x.toString
w=this.b
v=w[x]-(q+s)
for(s=this.c,u=0;u<s;++u){if(u===x)continue
t=w[u]
if(Math.abs(v-t)<1e-10){v=t
break}}s=new PART9.eN(!1,null,null)
s.a=v
s.x=x
return s},
$S:z+6}
PART9.rE7.prototype={
$1(d){return d==1/0||d==-1/0},
$S:46}
PART9.cwr.prototype={
$1(d){return d>this.a},
$S:46}
PART9.wVU.prototype={
$1(d){var x=this.a
return d>=y.p.a(N.jU.prototype.gHv.call(x)).d},
$S:46}
PART9.ian.prototype={
$0(){var x,w,v,u=this,t=u.a,s=t.b,r=t.a
if(s==r)t.c=!1
x=u.b
s=s.e
s.toString
w=t.b=N.Lh(x).CT("pvS.1").a(s).UH$
s=w==null
if(s)t.c=!1
v=++t.d
if(!t.c){if(!s){s=w.e
s.toString
s=y.D.a(s).b
s.toString
v=s!==v
s=v}else s=!0
v=u.c
if(s){w=x.h7K(v,r,!0)
t.b=w
if(w==null)return!1}else w.yEC(0,v,!0)
s=t.a=t.b}else s=w
s.toString
u.d.$1(s)
if(!t.e&&C.Nm.Vr(u.e,new PART9.HeE(x))){t.e=!0
t=t.b.e
t.toString
t=y.D.a(t).b
t.toString
x.qJ=t}return!0},
$S:17}
PART9.HeE.prototype={
$1(d){var x=this.a
return d>=y.p.a(N.jU.prototype.gHv.call(x)).d},
$S:46}
PART9.kQg.prototype={
$1(d){return d-this.a.cd<this.b},
$S:46}
PART9.i7a.prototype={
$1(d){return d-this.a.cd<this.b},
$S:46}
PART9.QQE.prototype={
$2(d,e){var x=d.e
if(x==null)x=1
return Math.min(x,e)},
$S:z+7}
PART9.tYT.prototype={
$1(d){return this.a.RZ?d.b:d.a},
$S:628}
PART9.Wn8.prototype={
$1(d){var x=this.a.RZ,w=d.rx
return x?w.b:w.a},
$S:14}
PART9.X85.prototype={
$1(d){var x=this.a,w=x.ij?x.TQ-d-1:d
return w*this.b},
$S:629}
PART9.Llx.prototype={
$2(d,e){var x=this.a,w=x.e.rGP(e,x.d),v=this.b,u=v==null?null:C.jn.xG(v+w-1,w)*2-1
return new N.SliverList(new N.SliverChildBuilderDelegate(new PART9.LBT(x,w,e),u,!0,!0,!0,0,N.Um(),null),null)},
$S:630}
PART9.LBT.prototype={
$2(d,e){var x,w,v,u,t,s,r,q=this
if((e&1)===1)return new PART9.MzJ(q.a.c,null)
x=q.b
w=C.jn.B(e,2)*x
v=N.J([],y.o)
for(u=q.a,t=u.r,s=0;s<x;++s)v.push(u.bFs(d,w+s,t))
r=new N.u6(v,y.U)
if(!r.gw(r).l())return null
return new PART9.bkE(u.d,x,q.c.y,N.Y1(r,!0,y.l),null)},
$S:98};(function aliases(){var x=PART9.KLt.prototype
x.Jj8=x.oNP})();(function installTearOffs(){var x=a.installStaticTearOff,w=a._instance_1u,v=a._static_1
x(PART9,"wx",3,null,["$3"],["quiltedToPattern"],8,0)
x(PART9,"Krp",2,null,["$3$parentUsesSize","$2"],["nIB",function(d,e){return PART9.nIB(d,e,!1)}],2,0)
x(PART9,"UQW",2,null,["$3$parentUsesSize","$2"],["z8M",function(d,e){return PART9.z8M(d,e,!1)}],2,0)
var u
w(u=PART9.y3I.prototype,"gTsy","n4G",1)
w(u,"gc9D","Emj",1)
w(u,"gL3E","MZD",1)
w(u,"gBhg","Gse",1)
v(PART9,"B1","EIK",0)
v(PART9,"dt","oz9",9)
v(PART9,"SG","Hln",10)
v(PART9,"Ik","oiN",0)
v(PART9,"hm","Pjh",0)
v(PART9,"y6","JYG",11)
v(PART9,"Oh","Go2",12)
v(PART9,"vm","X8O",0)
v(PART9,"AS","MyP",13)
v(PART9,"pH","Xpv",14)
v(PART9,"C0","quiltedGridRepeatPattern",15)
x(PART9,"QU",5,null,["$5"],["sliverWovenGridDelegateCount"],16,0)
x(PART9,"ZG",5,null,["$5"],["sliverWovenGridDelegateExtent"],17,0)
v(PART9,"av","MDc",18)
v(PART9,"Tw","Nqr",19)
v(PART9,"DY","vuP",20)
v(PART9,"Av","air",0)})();(function inheritance(){var x=a.mixinHard,w=a.mixin,v=a.inherit,u=a.inheritMany
v(PART9.YE1,N.Jv2)
v(PART9.GVJ,N.lLS)
v(PART9.arY,PART9.GVJ)
v(PART9.Jo6,PART9.arY)
u(N.Mh,[PART9.QuiltedGridTile,PART9.Il,PART9.dGx,PART9.BrN,PART9.StairedGridTile,PART9.WovenGridTile,PART9.SDQ,PART9.Xe3,PART9.fR3])
u(N.fLz,[PART9.SliverQuiltedGridDelegate,PART9.KLt])
u(N.mBH,[PART9.FUd,PART9.H9H])
u(PART9.dGx,[PART9.B36,PART9.u8P,PART9.jUV])
u(N.Tp,[PART9.Hx,PART9.bX,PART9.AJV,PART9.nwa,PART9.ST,PART9.zZg,PART9.z8a,PART9.diE,PART9.rE7,PART9.cwr,PART9.wVU,PART9.HeE,PART9.kQg,PART9.i7a,PART9.tYT,PART9.Wn8,PART9.X85])
u(PART9.KLt,[PART9.SliverStairedGridDelegate,PART9.V8])
v(PART9.eN,N.KiY)
v(PART9.l4t,N.lbZ)
u(N.Ay3,[PART9.iex,PART9.ian])
u(PART9.SDQ,[PART9.SliverSimpleGridDelegateWithFixedCrossAxisCount,PART9.SliverSimpleGridDelegateWithMaxCrossAxisExtent])
u(N.k3m,[PART9.AQd,PART9.JOv])
u(PART9.Xe3,[PART9.StaggeredGridDelegateWithFixedCrossAxisCount,PART9.StaggeredGridDelegateWithMaxCrossAxisExtent])
u(N.Qc2,[PART9.vUJ,PART9.B08])
v(PART9.pLz,PART9.vUJ)
v(PART9.y3I,PART9.pLz)
u(N.E1N,[PART9.QQE,PART9.Llx,PART9.LBT])
v(PART9.XbJ,PART9.B08)
v(PART9.OJO,PART9.XbJ)
u(N.fbC,[PART9.AlignedGridView,PART9.MasonryGridView])
u(N.m2v,[PART9.Bvq,PART9.MzJ])
v(PART9.SliverMasonryGrid,N.rjQ)
u(N.cIT,[PART9.StaggeredGrid,PART9.bkE])
v(PART9.StaggeredGridTile,N.BOs)
x(PART9.GVJ,N.AOA)
w(PART9.arY,N.cqb)
x(PART9.vUJ,N.pvS)
w(PART9.pLz,N.BaI)
x(PART9.B08,N.pvS)
w(PART9.XbJ,N.BaI)})()
N.xbv(b.typeUniverse,JSON.parse('{"YE1":{"Jv2":["im8"],"rN9":[],"Widget":[],"Jv2.0":"im8"},"Jo6":{"cqb":["im8","lLS"],"lLS":[],"AOA":["lLS"],"jU":[],"F9":[],"Y3C":[],"cqb.0":"im8"},"B36":{"dGx":[]},"u8P":{"dGx":[]},"jUV":{"dGx":[]},"eN":{"KiY":[],"xac":[],"oO8":["Qc2"],"kWG":[]},"l4t":{"lbZ":[],"lLS":[],"pvS":["Qc2","KiY"],"jU":[],"F9":[],"Y3C":[],"pvS.1":"KiY","pvS.0":"Qc2"},"AQd":{"tD":[],"oO8":["Qc2"]},"y3I":{"BaI":["Qc2","AQd"],"Qc2":[],"pvS":["Qc2","AQd"],"jU":[],"F9":[],"Y3C":[],"pvS.1":"AQd","BaI.1":"AQd","pvS.0":"Qc2"},"JOv":{"tD":[],"oO8":["Qc2"]},"OJO":{"BaI":["Qc2","JOv"],"Qc2":[],"pvS":["Qc2","JOv"],"jU":[],"F9":[],"Y3C":[],"pvS.1":"JOv","BaI.1":"JOv","pvS.0":"Qc2"},"AlignedGridView":{"m2v":[],"Widget":[]},"MasonryGridView":{"m2v":[],"Widget":[]},"Bvq":{"m2v":[],"Widget":[]},"MzJ":{"m2v":[],"Widget":[]},"SliverMasonryGrid":{"rjQ":[],"rN9":[],"Widget":[]},"StaggeredGrid":{"cIT":[],"rN9":[],"Widget":[]},"StaggeredGridTile":{"BOs":["AQd"],"WFg":[],"Widget":[],"BOs.T":"AQd"},"bkE":{"cIT":[],"rN9":[],"Widget":[]}}'))
N.FF0(b.typeUniverse,JSON.parse('{"KLt":1}'))
var y=(function rtii(){var x=N.lRH
return{k:x("BoxConstraints"),I:x("Directionality"),E:x("jd<AlignedGridView>"),z:x("jd<MasonryGridView>"),H:x("jd<SliverMasonryGrid>"),q:x("jd<StaggeredGrid>"),_:x("jd<StaggeredGridTile>"),n:x("jd<CP5>"),t:x("jd<Ij>"),o:x("jd<Widget?>"),x:x("Qc2"),p:x("im8"),d:x("DIh"),m:x("eN"),F:x("mH"),D:x("KiY"),C:x("AQd"),r:x("JOv"),U:x("u6<Widget>"),l:x("Widget"),i:x("CP5"),S:x("Ij")}})();(function constants(){PART9_C.QC=new N.AlignmentDirectional(0,0)
PART9_C.NY=new N.GZn(N.Zvr(),N.lRH("GZn<Ij>"))
PART9_C.Ry=new N.GZn(N.TpV(),N.lRH("GZn<CP5>"))
PART9_C.jl=new PART9.u8P()
PART9_C.zh=new PART9.jUV()
PART9_C.zY=new PART9.B36()
PART9_C.kg=new N.DIh(0,0,0,0)
PART9_C.LF=new PART9.fR3(0,1/0)})()}
$__dart_deferred_initializers__["i2l3O8w6ZXsNPwOkTH2nlTEHFqI="] = $__dart_deferred_initializers__.current

window.init.initializeLoadedHunk("i2l3O8w6ZXsNPwOkTH2nlTEHFqI=");

