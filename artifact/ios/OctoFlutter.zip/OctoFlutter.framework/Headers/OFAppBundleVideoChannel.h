//
//  OFAppBundleVideoChannel.h
//  octoflutter
//
//  Created by Simon Yang on 2022/2/25.
//

#import "OFAppBundlePluginBase.h"

NS_ASSUME_NONNULL_BEGIN

@interface OFAppBundleVideoChannel : OFAppBundleMCBase

+ (NSString*)getBasePlayerEventChannelName;
@end

NS_ASSUME_NONNULL_END
