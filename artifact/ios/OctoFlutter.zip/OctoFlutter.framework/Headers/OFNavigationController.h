//
//  OFNavigationController.h
//  octoflutter_Example
//
//  Created by Simon Yang on 2022/2/25.
//  Copyright © 2022 itechblue@163.com. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface OFNavigationController : UINavigationController

@end

NS_ASSUME_NONNULL_END
